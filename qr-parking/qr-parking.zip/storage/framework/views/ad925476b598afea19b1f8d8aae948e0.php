
<?php $__env->startSection('content'); ?>
    <main class="p-8 min-h-[80vh]  bg-white flex flex-col justify-between">
        <!-- Judul Atas -->
        <div class="text-center mb-8">
            <h1 class="text-2xl font-bold">DASH<span class="text-red-500">BOARD</span></h1>
        </div>

        <!-- Banner & Menu -->
        <div
            class="flex flex-col lg:flex-row justify-between items-center bg-[url('https://www.transparenttextures.com/patterns/axiom-pattern.png')] bg-repeat bg-white rounded-2xl shadow-inner overflow-hidden px-6 py-8 gap-6">
            <!-- Banner -->
            <!-- Banner -->
                    <div class="lg:w-1/2 w-full h-full flex flex-col justify-center items-center gap-4">
                        <!-- Gambar Banner -->
                        <div class="w-full flex justify-center">
                            <img src="<?php echo e(asset('img/banner.png')); ?>" alt="Gambar mobil, hp, dan QR scanner"
                                class="w-4/5 max-w-sm drop-shadow-xl rounded-md">
                        </div>

                        <!-- Box Sambutan -->
                        <div class="p-4 w-3/4 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] bg-white bg-repeat shadow rounded"
                            x-data="{
                                greeting: 'Selamat datang '.split(''),
                                nama: '<?php echo e(session('adminData')->nama_lengkap); ?>'.split(''),
                                delay: 50,
                                showParagraph: false
                            }" x-init="setTimeout(() => showParagraph = true, (greeting.length + nama.length) * delay + 500)">

                            <!-- Animasi Sambutan -->
                            <h2 class="text-xl font-bold mb-4 flex flex-wrap space-x-1 select-none" x-data="{
                                greeting: 'Selamat datang '.split(''),
                                nama: '<?php echo e(session('adminData')->nama_lengkap); ?>'.split(''),
                                delay: 50,
                                animate: true,
                                toggle() {
                                    this.animate = false;
                                    setTimeout(() => this.animate = true, 300);
                                }
                            }"
                                x-init="toggle();
                                setInterval(() => toggle(), 10000);">
                                <template x-for="(char, index) in greeting" :key="'g' + index">
                                    <span x-text="char"
                                        :class="animate ? 'opacity-100 scale-100 blur-0 transition-all duration-300' :
                                            'opacity-0 scale-150 blur-sm transition-none'"
                                        :style="animate ? 'transition-delay:' + (index * delay) + 'ms' : ''"
                                        class="text-gray-800 font-semibold"></span>
                                </template>
                                <template x-for="(char, index) in nama" :key="'n' + index">
                                    <span x-text="char"
                                        :class="animate ? 'opacity-100 scale-100 blur-0 transition-all duration-300' :
                                            'opacity-0 scale-150 blur-sm transition-none'"
                                        :style="animate ? 'transition-delay:' + ((greeting.length + index) * delay) + 'ms' : ''"
                                        class="text-red-700 font-extrabold drop-shadow"></span>
                                </template>
                            </h2>

                            <!-- Paragraf Deskripsi -->
                            <p class="text-sm text-gray-600 leading-relaxed max-w-xl mt-4" x-show="showParagraph"
                                x-transition:enter="transition ease-out duration-1000"
                                x-transition:enter-start="opacity-0 translate-y-2"
                                x-transition:enter-end="opacity-100 translate-y-0">
                                Aplikasi Parkir Kendaraan ini dibuat untuk pendataan kendaraan yang masuk/keluar area parkiran.
                                Pencatatan
                                kendaraan ini dibuat secara elektronik dengan penerapan kode QR yang dapat dipindai. Gunakanlah
                                browser
                                <strong>Google Chrome</strong> agar aplikasi ini dapat berjalan secara maksimal.
                            </p>
                        </div>
                    </div>


            <!-- Menu Dashboard -->
            <div class="lg:w-1/2 w-full h-full flex flex-col justify-center px-6">
                <h2 class="text-3xl font-bold text-gray-800 mb-6 border-b border-red-300 pb-2">
                    Menu Dashboard
                </h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <?php $__currentLoopData = [['icon' => 'plus', 'text' => 'Tambah Data Parkir Masuk'], ['icon' => 'plus', 'text' => 'Tambah Data Parkir Keluar'], ['icon' => 'list', 'text' => 'Lihat Data Parkir Masuk'], ['icon' => 'list', 'text' => 'Lihat Data Parkir Keluar'], ['icon' => 'list', 'text' => 'Lihat Data Parkir Masuk & Keluar'], ['icon' => 'edit', 'text' => 'Ubah Data Aplikasi'], ['icon' => 'edit', 'text' => 'Ubah Data Latar Belakang'], ['icon' => 'car', 'text' => 'Lihat Data Jenis Kendaraan & Tarif Parkir']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div
                            class="bg-white rounded-xl p-4 flex items-center gap-4 shadow-md hover:shadow-lg transition duration-300 hover:scale-[1.02] hover:bg-red-50 group cursor-pointer">
                            <div class="bg-red-500 p-3 rounded-full shadow group-hover:bg-red-600 transition duration-300">
                                <i class="fas fa-<?php echo e($item['icon']); ?> text-white text-lg"></i>
                            </div>
                            <span class="text-red-600 font-semibold text-sm sm:text-base group-hover:text-red-700">
                                <?php echo e($item['text']); ?>

                            </span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <!-- Welcome Box -->
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\qr-parking\resources\views/Admin/index.blade.php ENDPATH**/ ?>