
<?php $__env->startSection('content'); ?>
    <main class="mx-auto " style="max-width: 90%;">

        <?php if(session('success')): ?>
            <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
            <script>
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil',
                    text: "<?php echo e(session('success')); ?>",
                    timer: 2500,
                    showConfirmButton: false,
                });
            </script>
        <?php endif; ?>

        <!-- Main Content -->
        <div class="flex flex-col md:flex-row justify-center p-4">
            <!-- Form Section -->
            <div class="bg-white shadow-md rounded-lg p-6 m-4 w-full md:w-1/2 border-t-2 border-red-500 border-opacity-50">
                <h2 class="text-lg font-bold mb-6 flex items-center border-b border-gray-300 pb-2">
                    <i class="fas fa-user mr-2 text-black-500 text-xl">
                    </i>
                    Form Tambah Staff
                </h2>
                <form action="<?php echo e(route('admin.storeStaff')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

                        <div>
                            <label class="block text-sm font-semibold text-gray-900 mb-1">
                                Nama Lengkap <span class="text-red-500">*</span>
                            </label>
                            <input type="text" name="nama_lengkap" value="<?php echo e(old('nama_lengkap')); ?>"
                                placeholder="Masukkan nama lengkap"
                                class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500"
                                required />
                            <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-900 mb-1">
                                Photo
                            </label>
                            <input type="file" name="photo"
                                class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500" />
                            <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-900 mb-1">
                                Jenis Kelamin <span class="text-red-500">*</span>
                            </label>
                            <select name="jenis_kelamin"
                                class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500"
                                required>
                                <option value="" disabled <?php echo e(old('jenis_kelamin') ? '' : 'selected'); ?>>Pilih jenis
                                    kelamin</option>
                                <option value="Laki-laki" <?php echo e(old('jenis_kelamin') == 'Laki-laki' ? 'selected' : ''); ?>>
                                    Laki-laki</option>
                                <option value="Perempuan" <?php echo e(old('jenis_kelamin') == 'Perempuan' ? 'selected' : ''); ?>>
                                    Perempuan</option>
                            </select>
                            <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <!-- Handphone -->
                            <label class="block text-sm font-semibold text-gray-900 mb-1">
                                Handphone
                            </label>
                            <input type="text" name="handphone" value="<?php echo e(old('handphone')); ?>"
                                placeholder="Contoh: 081234567890"
                                class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500" />
                            <?php $__errorArgs = ['handphone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <!-- Username -->
                            <label class="block text-sm font-semibold text-gray-900 mb-1">
                                Username (Email) <span class="text-red-500">*</span>
                            </label>
                            <input type="email" name="username" value="<?php echo e(old('username')); ?>"
                                placeholder="Tuliskan alamat email aktif"
                                class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500"
                                required />
                            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <!-- Password -->
                            <label class="block text-sm font-semibold text-gray-900 mb-1">
                                Password Default <span class="text-red-500">*</span>
                            </label>
                            <input type="password" name="password" value="" placeholder="Password default: 123456"
                                class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500"
                                required />
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <!-- Password -->
                            <label class="block text-sm font-semibold text-gray-900 mb-1">
                                Password Confirmation <span class="text-red-500">*</span>
                            </label>
                            <input type="password" name="password_confirmation" value=""
                                placeholder="Password default: 123456"
                                class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500"
                                required />
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>

                    <div class="mt-6">
                        <!-- Alamat -->
                        <label class="block text-sm font-semibold text-gray-900 mb-1">
                            Alamat
                        </label>
                        <textarea name="alamat" placeholder="Masukkan alamat lengkap"
                            class="block w-full px-3 py-3 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500"
                            rows="4"><?php echo e(old('alamat')); ?></textarea>
                        <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="flex justify-end mt-6">
                        <button type="submit"
                            class="bg-blue-500 text-white px-5 py-2 rounded-md mr-3 flex items-center hover:bg-blue-600 transition duration-200">
                            <i class="fas fa-save mr-2"></i>
                            Simpan
                        </button>
                        <a href="<?php echo e(url()->previous()); ?>"
                            class="bg-red-500 text-white px-5 py-2 rounded-md flex items-center hover:bg-red-600 transition duration-200">
                            <i class="fas fa-times mr-2"></i>
                            Batal
                        </a>
                    </div>
                </form>


            </div>
            <!-- Data Table Section -->
            <div class="bg-white shadow-md rounded-lg p-6 m-4 w-full md:w-1/2">
                <h2 class="text-lg font-bold mb-4 flex items-center">
                    <i class="fas fa-table mr-2">
                    </i>
                    Data Tabel Staffs
                </h2>
                <div class="flex justify-between items-center mb-4">
                    <div>
                        <label class="text-sm">
                            Show
                            <select class="border-gray-300 rounded-md shadow-sm">
                                <option>
                                    10
                                </option>
                            </select>
                            entries
                        </label>
                    </div>
                    <div>
                        <label class="text-sm">
                            Search:
                            <input class="border-gray-300 rounded-md shadow-sm" type="text" />
                        </label>
                    </div>
                </div>
                <table class="min-w-full bg-white">
                    <thead>
                        <tr class="bg-red-500 text-white">
                            <th class="py-2 px-4">No.</th>
                            <th class="py-2 px-4">Nama</th>
                            <th class="py-2 px-4">Username</th>
                            <th class="py-2 px-4">Password</th>
                            <th class="py-2 px-4">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $Staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border-b text-center">
                                <td class="border p-2 text-center">
                                    <?php echo e($loop->iteration); ?>

                                </td>

                                <td class="py-2 px-4"><?php echo e($Staff->nama_lengkap); ?></td>
                                <td class="py-2 px-4"><?php echo e($Staff->username); ?></td>
                                <td class="py-2 px-4">********</td>

                                <td class="py-2 px-4">
                                    <div class="flex justify-center space-x-2">
                                        <!-- Tombol Edit -->
                                        <a href="javascript:void(0);" onclick="openEditModal(<?php echo e($Staff->id_users); ?>)"
                                            class="text-blue-500 hover:text-blue-700" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>


                                        <!-- Modal Edit -->
                                        <div id="editModal"
                                            class="fixed inset-0 z-50 hidden bg-black bg-opacity-50 flex items-center justify-center">
                                            <div class="bg-white rounded-lg shadow-lg p-6 w-full max-w-2xl relative">
                                                <!-- Tombol Close -->
                                                <button onclick="closeEditModal()"
                                                    class="absolute top-2 right-2 text-gray-500 hover:text-gray-800">
                                                    <i class="fas fa-times"></i>
                                                </button>

                                                <!-- Judul -->
                                                <h2 class="text-xl font-semibold mb-4 text-gray-800 border-b pb-2">Edit
                                                    Data User
                                                </h2>

                                                <form id="editUserForm" action="admin.editUser" method="POST"
                                                    enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                                        <input type="hidden" id="edit_id_users" name="id_users">

                                                        <div>
                                                            <label
                                                                class="block text-sm font-semibold text-gray-900 mb-1">Nama
                                                                Lengkap</label>
                                                            <input type="text" id="edit_nama_lengkap"
                                                                name="nama_lengkap1" value=""
                                                                placeholder="Masukkan nama lengkap"
                                                                class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500" />
                                                            <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>



                                                        <div>
                                                            <label
                                                                class="block text-sm font-semibold text-gray-900 mb-1">Jenis
                                                                Kelamin</label>
                                                            <select name="jenis_kelamin2"
                                                                class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500">
                                                                <option value="" disabled
                                                                    <?php echo e(old('jenis_kelamin') ? '' : 'selected'); ?>>Pilih
                                                                    jenis
                                                                    kelamin</option>
                                                                <option value="Laki-laki"
                                                                    <?php echo e(old('jenis_kelamin') == 'Laki-laki' ? 'selected' : ''); ?>>
                                                                    Laki-laki</option>
                                                                <option value="Perempuan"
                                                                    <?php echo e(old('jenis_kelamin') == 'Perempuan' ? 'selected' : ''); ?>>
                                                                    Perempuan</option>
                                                            </select>
                                                            <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>

                                                        <div>
                                                            <label
                                                                class="block text-sm font-semibold text-gray-900 mb-1">No
                                                                Handphone</label>
                                                            <input id="edit_no_hp" type="text" name="handphone1"
                                                                value="<?php echo e(old('handphone')); ?>"
                                                                placeholder="Contoh: 081234567890"
                                                                class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500" />
                                                            <?php $__errorArgs = ['handphone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>

                                                        <div>
                                                            <label
                                                                class="block text-sm font-semibold text-gray-900 mb-1">Email
                                                                (Username)
                                                            </label>
                                                            <input id="edit_email" type="email" name="username1"
                                                                value="<?php echo e(old('username')); ?>"
                                                                placeholder="Tuliskan alamat email aktif"
                                                                class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500" />
                                                            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>

                                                        <div>
                                                            <label
                                                                class="block text-sm font-semibold text-gray-900 mb-1">Password</label>
                                                            <input id="edit_password" type="password" name="password1"
                                                                placeholder="Password default: 123456"
                                                                class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500" />
                                                            <?php $__errorArgs = ['password1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                        </div>

                                                        <div>
                                                            <label
                                                                class="block text-sm font-semibold text-gray-900 mb-1">Konfirmasi
                                                                Password</label>
                                                            <input type="password" name="password1_confirmation"
                                                                placeholder="Password default: 123456"
                                                                class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500" />
                                                            <?php $__errorArgs = ['password1_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                        </div>

                                                    </div>

                                                    <div class="mt-6">
                                                        <label
                                                            class="block text-sm font-semibold text-gray-900 mb-1">Alamat</label>
                                                        <textarea id="edit_alamat" name="alamat2" placeholder="Masukkan alamat lengkap"
                                                            class="block w-full px-3 py-3 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500"
                                                            rows="4"><?php echo e(old('alamat')); ?></textarea>
                                                        <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>

                                                    <div class="flex justify-end mt-6">
                                                        <div x-data="{ showModal: false, adminPassword: '' }">
                                                            <!-- Tombol Update -->
                                                            <button type="button" @click="showModal = true"
                                                                class="bg-blue-500 text-white px-5 py-2 rounded-md mr-3 flex items-center hover:bg-blue-600 transition duration-200">
                                                                <i class="fas fa-save mr-2"></i> Update
                                                            </button>

                                                            <!-- Modal Konfirmasi Password Admin -->
                                                            <div x-show="showModal"
                                                                class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50"
                                                                x-transition>
                                                                <div
                                                                    class="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
                                                                    <h2 class="text-xl font-semibold mb-4">Konfirmasi Aksi
                                                                    </h2>
                                                                    <p class="mb-3">Masukkan password admin untuk
                                                                        melanjutkan:
                                                                    </p>
                                                                    <input type="password" x-model="adminPassword"
                                                                        name="admin_password" placeholder="Password admin"
                                                                        class="w-full border border-gray-300 p-2 rounded mb-4">

                                                                    <div class="flex justify-end">
                                                                        <!-- Tombol batal: hanya tutup modal -->
                                                                        <button type="button" @click="showModal = false"
                                                                            class="px-4 py-2 bg-gray-300 text-gray-700 rounded mr-2 hover:bg-gray-400">
                                                                            Batal
                                                                        </button>

                                                                        <!-- Tombol lanjut -->
                                                                        <button type="button"
                                                                            @click="if (adminPassword.length > 0) $refs.submitButton.click()"
                                                                            class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">
                                                                            Lanjutkan
                                                                        </button>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <!-- Tombol submit form tersembunyi -->
                                                            <button type="submit" x-ref="submitButton"
                                                                class="hidden"></button>
                                                        </div>

                                                        <!-- Tombol batal luar (misalnya cancel edit form) -->
                                                        <a href="javascript:void(0);"
                                                            class="bg-red-500 text-white px-5 py-2 rounded-md flex items-center hover:bg-red-600 transition duration-200">
                                                            <i class="fas fa-times mr-2"></i> Batal
                                                        </a>
                                                    </div>

                                                </form>
                                            </div>
                                        </div>

                                        <!-- Tombol Hapus -->
                                        <form action="<?php echo e(route('admin.destroyStaff', $Staff->id_users)); ?>" method="POST"
                                            onsubmit="return confirm('Yakin ingin menghapus staff ini?')" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="text-red-500 hover:text-red-700"
                                                title="Hapus">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>


                <div class="flex justify-between items-center mt-4">
                    <div class="text-sm">
                        Showing 1 to 2 of 2 entries
                    </div>
                    <div class="flex space-x-2">
                        <button class="px-3 py-1 border rounded-md">
                            Previous
                        </button>
                        <button class="px-3 py-1 border rounded-md bg-blue-500 text-white">
                            1
                        </button>
                        <button class="px-3 py-1 border rounded-md">
                            Next
                        </button>
                    </div>
                </div>
                <div class="mt-4 text-sm text-gray-600">
                    <p>
                        Mohon berhati-hati jika ingin menghapus data kendaraan usahakan sebelum melakukan peng-inputan data
                        parkir, karena akan menyebabkan data error!
                    </p>
                </div>
            </div>
        </div>

        <div id="exportModal"
            class="hidden fixed inset-0 z-50 flex items-start justify-center bg-black bg-opacity-50 pt-24">
            <div class="bg-white rounded-lg shadow-lg w-full max-w-md">
                <div class="bg-red-600 text-white flex items-center justify-between p-4 rounded-t-lg">
                    <div class="flex items-center">
                        <i class="fas fa-car mr-2"></i>
                        <span class="font-semibold">Aplikasi Parkir Kendaraan</span>
                    </div>
                    <button class="text-white"><i class="fas fa-times" id="closeExportForm"></i></button>
                </div>
                <div class="p-6 text-center">
                    <i class="fas fa-exclamation-triangle text-4xl text-gray-600 mb-4"></i>
                    <h2 class="text-xl font-semibold mb-2">Apa anda yakin akan menghapus data ini?</h2>
                    <p class="text-blue-600 mb-1">ID: cVhibmNtV1FBY25mRVB0TIMZEpFZz09</p>
                    <p class="text-gray-600">Data akan dihapus secara permanen dari database!</p>
                </div>
                <div class="flex justify-end p-4 space-x-2">
                    <button class="bg-red-600 text-white px-4 py-2 rounded-lg flex items-center">
                        <i class="fas fa-times mr-2" id="closeExportForm"></i>Batal
                    </button>
                    <button class="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center">
                        <i class="fas fa-check mr-2"></i>Ya! Hapus
                    </button>
                </div>
            </div>
        </div>

        <div id="exportModal1"
            class="hidden fixed inset-0 z-50 flex items-start justify-center bg-black bg-opacity-50 pt-24">

            <div class="w-full max-w-3xl rounded-md shadow-lg bg-white">
                <!-- Header -->
                <div class="flex items-center justify-between bg-red-500 text-white px-4 py-2 rounded-t-md select-none">
                    <div class="flex items-center space-x-2 font-semibold text-sm sm:text-base">
                        <i class="fas fa-map-marker-alt">
                        </i>
                        <span>
                            Parkir Kendaraan - Ubah Data User
                        </span>
                    </div>
                    <button aria-label="Close" class="text-white text-sm sm:text-base font-semibold hover:opacity-80"
                        id="closeExportForm1">
                        X
                    </button>
                </div>
                <!-- Content -->
                <form class="p-6 space-y-6">
                    <!-- Profile Image -->
                    <div class="flex justify-center mb-6">
                        <img alt="User profile icon, blue silhouette of a person on a light gray circular background"
                            class="rounded-full border border-gray-300" height="80"
                            src="https://storage.googleapis.com/a1aa/image/40c594b4-b2bf-45fe-2e2d-259ea33370b5.jpg"
                            width="80" />
                    </div>
                    <!-- Form fields grid -->
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4 text-xs sm:text-sm">
                        <!-- Nama Lengkap -->
                        <div>
                            <label class="block mb-1 font-normal text-gray-700" for="namaLengkap">
                                Nama Lengkap
                            </label>
                            <input
                                class="w-full border border-gray-300 rounded px-2 py-1 text-gray-700 focus:outline-none focus:ring-1 focus:ring-red-500"
                                id="namaLengkap" name="namaLengkap" type="text" value="Julia Ransulangi" />
                        </div>
                        <!-- Ganti Photo -->
                        <div>
                            <label class="block mb-1 font-normal text-gray-700" for="gantiPhoto">
                                Ganti Photo
                            </label>
                            <input
                                class="w-full border border-gray-300 rounded px-2 py-1 text-gray-700 cursor-pointer focus:outline-none focus:ring-1 focus:ring-red-500"
                                id="gantiPhoto" name="gantiPhoto" type="file" />
                        </div>
                        <!-- Tempat Lahir -->
                        <div>
                            <label class="block mb-1 font-normal text-gray-700" for="tempatLahir">
                                Tempat Lahir
                            </label>
                            <input
                                class="w-full border border-gray-300 rounded px-2 py-1 text-gray-700 focus:outline-none focus:ring-1 focus:ring-red-500"
                                id="tempatLahir" name="tempatLahir" type="text" value="Jayapura" />
                        </div>
                        <!-- Tanggal Lahir -->
                        <div>
                            <label class="block mb-1 font-normal text-gray-700" for="tanggalLahir">
                                Tanggal Lahir
                            </label>
                            <input
                                class="w-full border border-gray-300 rounded px-2 py-1 text-gray-700 cursor-pointer focus:outline-none focus:ring-1 focus:ring-red-500"
                                id="tanggalLahir" name="tanggalLahir" type="date" value="1990-12-12" />
                        </div>
                        <!-- Jenis Kelamin -->
                        <div>
                            <label class="block mb-1 font-normal text-gray-700" for="jenisKelamin">
                                Jenis Kelamin
                            </label>
                            <select
                                class="w-full border border-gray-300 rounded px-2 py-1 text-gray-700 focus:outline-none focus:ring-1 focus:ring-red-500"
                                id="jenisKelamin" name="jenisKelamin">
                                <option>
                                    Perempuan
                                </option>
                            </select>
                        </div>
                        <!-- Agama -->
                        <div>
                            <label class="block mb-1 font-normal text-gray-700" for="agama">
                                Agama
                            </label>
                            <select
                                class="w-full border border-gray-300 rounded px-2 py-1 text-gray-700 focus:outline-none focus:ring-1 focus:ring-red-500"
                                id="agama" name="agama">
                                <option>
                                    Khatolik
                                </option>
                            </select>
                        </div>
                        <!-- Alamat -->
                        <div>
                            <label class="block mb-1 font-normal text-gray-700" for="alamat">
                                Alamat
                            </label>
                            <input
                                class="w-full border border-gray-300 rounded px-2 py-1 text-gray-700 focus:outline-none focus:ring-1 focus:ring-red-500"
                                id="alamat" name="alamat" type="text" value="Jalan Denganmu" />
                        </div>
                        <!-- Handphone -->
                        <div>
                            <label class="block mb-1 font-normal text-gray-700" for="handphone">
                                Handphone
                            </label>
                            <input
                                class="w-full border border-gray-300 rounded px-2 py-1 text-gray-700 focus:outline-none focus:ring-1 focus:ring-red-500"
                                id="handphone" name="handphone" type="text" value="123" />
                        </div>
                        <!-- Username -->
                        <div>
                            <label class="block mb-1 font-normal text-gray-700" for="username">
                                Username
                            </label>
                            <input
                                class="w-full border border-gray-300 rounded px-2 py-1 text-gray-700 focus:outline-none focus:ring-1 focus:ring-red-500"
                                id="username" name="username" type="text" value="jr@gmail.com" />
                        </div>
                        <!-- Ganti Password -->
                        <div>
                            <label class="block mb-1 font-normal text-gray-700" for="gantiPassword">
                                Ganti Password
                            </label>
                            <input
                                class="w-full border border-gray-300 rounded px-2 py-1 text-gray-400 italic focus:outline-none focus:ring-1 focus:ring-red-500"
                                id="gantiPassword" name="gantiPassword"
                                placeholder="Kosongkan Jika Password Tidak Diubah" type="text" />
                        </div>
                    </div>
                    <!-- Buttons -->
                    <div class="flex justify-end space-x-3 mt-6">
                        <button
                            class="bg-red-600 hover:bg-red-700 text-white text-xs sm:text-sm font-semibold px-4 py-2 rounded flex items-center space-x-2"
                            type="button">
                            <i class="fas fa-times">
                            </i>
                            <span>
                                Batal
                            </span>
                        </button>
                        <button
                            class="bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold px-4 py-2 rounded flex items-center space-x-2"
                            type="submit">
                            <i class="fas fa-check">
                            </i>
                            <span>
                                Simpan
                            </span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<script>
    function openEditModal(id) {
        // Tampilkan modal
        document.getElementById('editModal').classList.remove('hidden');

        // Set form action
        document.getElementById('editUserForm').action = `/admin/edit-user/${id}`;

        // Ambil data dari server
        fetch(`/admin/get-user/${id}`)
            .then(response => response.json())
            .then(user => {
                // Isi form dengan data user
                document.getElementById('edit_nama_lengkap').value = user.nama_lengkap || '';
                document.getElementById('edit_email').value = user.username || '';
                document.getElementById('edit_no_hp').value = user.no_hp || '';
                document.querySelector('select[name="jenis_kelamin2"]').value = user.jenis_kelamin || '';
                document.querySelector('textarea[name="alamat2"]').value = user.alamat || '';

                // ✅ Tambahkan jika kamu juga ingin menampilkan id_users di form (readonly atau hidden)
                document.getElementById('edit_id_users').value = user.id_users || '';
            })
            .catch(error => {
                console.error('Gagal mengambil data user:', error);
            });
    }


    function closeEditModal() {
        document.getElementById('editModal').classList.add('hidden');
    }
</script>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\qr-parking\resources\views/admin/kelolaStaffMaster.blade.php ENDPATH**/ ?>