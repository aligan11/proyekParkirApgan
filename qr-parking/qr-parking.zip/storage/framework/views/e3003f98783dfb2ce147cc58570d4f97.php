
<?php $__env->startSection('content'); ?>
    <main class="p-8">
        <h2 class="text-3xl font-bold text-gray-800 mb-6 flex items-center gap-2">
            <i class="fas fa-parking text-red-600"></i> Data Parkir Keluar
        </h2>

        <div class="bg-white shadow-lg rounded-lg overflow-hidden">
            <div
                class="p-5 border-b border-gray-200 flex flex-col md:flex-row justify-between items-center gap-4 md:gap-0 bg-red-50">
                <div class="flex items-center space-x-3 text-gray-700 text-lg font-semibold">
                    <i class="fas fa-table text-2xl text-red-600"></i>
                    <span>Data Tabel Parkir Keluar Hari Ini</span>
                </div>
                <!-- Tombol Ekspor -->
                <button id="toggleExportForm"
                    class="bg-green-600 hover:bg-green-700 focus:ring-4 focus:ring-green-300 text-white px-5 py-2 rounded-md shadow-md transition duration-300 flex items-center gap-2 font-medium">
                    <i class="fas fa-file-excel text-lg"></i> Ekspor Data Parkir Ke Excel
                </button>
            </div>

            <!-- Modal Export -->
            <div id="exportModal" class="hidden fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
                <div id="exportForm" class="bg-white shadow-xl rounded-xl w-full max-w-md">
                    <div class="bg-red-500 text-white px-5 py-3 rounded-t-xl flex justify-between items-center">
                        <div class="flex items-center space-x-2">
                            <i class="fas fa-file-export"></i>
                            <h3 class="text-lg font-semibold">Ekspor Data Parkir</h3>
                        </div>
                        <button id="closeExportForm"><i class="fas fa-times"></i></button>
                    </div>
                    <div class="p-5 space-y-4">
                        <div class="flex gap-4">
                            <div class="w-1/2">
                                <label class="text-sm font-medium text-gray-700">Dari Tanggal</label>
                                <div class="relative">
                                    <input type="text"
                                        class="w-full border border-gray-300 rounded px-3 py-2 pr-10 focus:outline-none focus:ring-2 focus:ring-red-400"
                                        placeholder="dd/mm/yyyy">
                                    <i class="fas fa-calendar-alt absolute right-3 top-3 text-gray-400"></i>
                                </div>
                            </div>
                            <div class="w-1/2">
                                <label class="text-sm font-medium text-gray-700">Sampai Tanggal</label>
                                <div class="relative">
                                    <input type="text"
                                        class="w-full border border-gray-300 rounded px-3 py-2 pr-10 focus:outline-none focus:ring-2 focus:ring-red-400"
                                        placeholder="dd/mm/yyyy">
                                    <i class="fas fa-calendar-alt absolute right-3 top-3 text-gray-400"></i>
                                </div>
                            </div>
                        </div>
                        <p class="text-gray-600 text-sm flex items-center">
                            <i class="fas fa-info-circle text-yellow-500 mr-2"></i>
                            Maksimal 500 data per ekspor.
                        </p>
                        <div class="flex justify-end gap-2">
                            <button class="bg-gray-300 hover:bg-gray-400 text-gray-700 px-4 py-2 rounded flex items-center">
                                <i class="fas fa-times mr-2"></i> Batal
                            </button>
                            <button class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded flex items-center">
                                <i class="fas fa-download mr-2"></i> Unduh
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="p-5 overflow-x-auto">
                <form method="GET" class="flex justify-between items-center flex-wrap gap-2 mb-4">
                    <!-- KIRI: Show & Urutkan -->
                    <div class="flex items-center gap-4">
                        <div>
                            <label class="text-sm font-medium text-gray-700">Show
                                <select name="perPage" onchange="this.form.submit()" class="border rounded p-1 ml-1">
                                    <?php $__currentLoopData = [5, 10, 25, 50, 100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $limit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($limit); ?>"
                                            <?php echo e(request('perPage', 5) == $limit ? 'selected' : ''); ?>>
                                            <?php echo e($limit); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select> entries
                            </label>
                        </div>

                        <div>
                            <label class="text-sm font-medium text-gray-700">Urutkan:
                                <select name="sort" onchange="this.form.submit()" class="border rounded p-1 ml-1">
                                    <option value="desc" <?php echo e(request('sort', 'desc') == 'desc' ? 'selected' : ''); ?>>Terbaru
                                    </option>
                                    <option value="asc" <?php echo e(request('sort') == 'asc' ? 'selected' : ''); ?>>Terlama</option>
                                </select>
                            </label>
                        </div>
                    </div>

                    <!-- KANAN: Search -->
                    <div>
                        <label class="text-sm font-medium text-gray-700">
                            Search:
                            <input type="search" name="search" value="<?php echo e(request('search')); ?>"
                                class="border rounded p-1 ml-1" placeholder="Cari...">
                        </label>
                    </div>
                </form>


                <table class="min-w-full border-collapse bg-white text-gray-800 shadow-md rounded-md">
                    <thead>
                        <tr class="bg-red-600 text-white text-sm uppercase tracking-wide">
                            <th class="py-3 px-4 text-center">No.</th>
                            <th class="py-3 px-4 text-left">Kode Parkir</th>
                            <th class="py-3 px-4 text-left">Plat Nomor</th>
                            <th class="py-3 px-4 text-left">Jenis Kendaraan</th>
                            <th class="py-3 px-4 text-left">Tipe/Merek Kendaraan</th>
                            <th class="py-3 px-4 text-center">Waktu Keluar</th>
                            <th class="py-3 px-4 text-right">Lokasi</th>
                            <th class="py-3 px-4 text-center">Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200 text-sm">
                        <!-- Contoh baris data -->
                        <?php $__currentLoopData = $jenisKendaraan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-50 transition-colors duration-150 cursor-pointer">
                                <td class="py-3 px-4 text-center"><?php echo e($loop->iteration + $jenisKendaraan->firstItem() - 1); ?>

                                </td>
                                <td class="py-3 px-4 font-semibold"><?php echo e($item->kode_parkir); ?></td>
                                <td class="py-3 px-4"><?php echo e($item->platNomor->plat_nomor); ?></td>
                                <td class="py-3 px-4"><?php echo e($item->tipeKendaraan->jenis->nama_kendaraan); ?></td>
                                <td class="py-3 px-4"><?php echo e($item->merkKendaraan->merk_kendaraan); ?></td>
                                <td class="py-3 px-4">
                                    <div class="bg-gray-100 text-center text-xs rounded px-2 py-1">
                                        <?php echo e($item->waktu_keluar); ?>

                                    </div>
                                </td>

                                <td class="py-3 px-4 text-right "><?php echo e($item->lokasi ?? '-'); ?></td>
                                <td class="py-3 px-4 text-center">
                                    <button
                                        class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded-md font-semibold transition">
                                        <?php echo e($item->status); ?>

                                    </button>
                                </td>
                            </tr>

                            <!-- Tambahkan baris lainnya di bawah ini -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!--
                <tr>
                  ...
                </tr>
                -->
                    </tbody>
                </table>
                <div class="flex justify-between items-center mt-4">
                    <div>
                        Showing <?php echo e($jenisKendaraan->firstItem()); ?> to <?php echo e($jenisKendaraan->lastItem()); ?> of
                        <?php echo e($jenisKendaraan->total()); ?> entries
                    </div>
                    <div>
                        <?php echo e($jenisKendaraan->appends(request()->query())->links('vendor.pagination.custom')); ?>

                    </div>

                </div>

            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const toggleBtn = document.getElementById("toggleExportForm");
        const modal = document.getElementById("exportModal");
        const closeBtn = document.getElementById("closeExportForm");

        toggleBtn.addEventListener("click", () => {
            modal.classList.remove("hidden");
        });

        closeBtn.addEventListener("click", () => {
            modal.classList.add("hidden");
        });

        // Kalau klik di luar form, modal ditutup juga
        modal.addEventListener("click", function(e) {
            if (e.target === modal) {
                modal.classList.add("hidden");
            }
        });
    });
</script>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\qr-parking\resources\views/Admin/dataParkirKeluarRekapitulasi.blade.php ENDPATH**/ ?>