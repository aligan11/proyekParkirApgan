<?php if($paginator->hasPages()): ?>
    <nav class="flex justify-center space-x-1 mt-4">
        
        <?php if($paginator->onFirstPage()): ?>
            <span class="px-3 py-1 rounded bg-gray-200 text-gray-500 cursor-not-allowed">Previous</span>
        <?php else: ?>
            <a href="<?php echo e($paginator->previousPageUrl()); ?>"
                class="px-3 py-1 rounded bg-red-600 text-white hover:bg-red-700 transition">Previous</a>
        <?php endif; ?>

        
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <?php if(is_string($element)): ?>
                <span class="px-3 py-1 rounded bg-gray-200 text-gray-600"><?php echo e($element); ?></span>
            <?php endif; ?>

            
            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <span class="px-3 py-1 rounded bg-red-700 text-white"><?php echo e($page); ?></span>
                    <?php else: ?>
                        <a href="<?php echo e($url); ?>"
                            class="px-3 py-1 rounded bg-red-100 text-red-700 hover:bg-red-200 transition"><?php echo e($page); ?></a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>"
                class="px-3 py-1 rounded bg-red-600 text-white hover:bg-red-700 transition">Next</a>
        <?php else: ?>
            <span class="px-3 py-1 rounded bg-gray-200 text-gray-500 cursor-not-allowed">Next</span>
        <?php endif; ?>
    </nav>
<?php endif; ?>
<?php /**PATH C:\laragon\www\qr-parking\resources\views/vendor/pagination/custom.blade.php ENDPATH**/ ?>