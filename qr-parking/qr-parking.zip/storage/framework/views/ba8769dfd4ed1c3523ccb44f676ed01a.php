
<?php $__env->startSection('content'); ?>
  <div class="max-w-5xl mx-auto mt-6 bg-white shadow-md rounded-md">
   <div class="border-b-2 border-red-600 p-4">
    <h1 class="text-lg font-bold">
     APLIKASI PARKIR KENDARAAN
     <span class="text-red-600">
      <?php echo e($logo->nama_aplikasi); ?>

     </span>
    </h1>
   </div>
   <div class="p-6">
    <div class="border-b-2 border-red-600 mb-4">
     <h2 class="text-lg font-bold flex items-center">
      <i class="far fa-file-alt mr-2">
      </i>
      Form Rincian/Ubah Data Latar Belakang
     </h2>
    </div>
    <div class="flex space-x-6">
     <div class="flex-none">
      <img alt="Gambar Login/Dashboard" class="border" height="200" src="https://storage.googleapis.com/a1aa/image/7ed1747c-0277-424c-56c2-876d9c87c7c0.jpg" width="300"/>
     </div>
     <div class="flex-grow">
      <div class="mb-4">
       <label class="block font-bold mb-2">
        Ganti Gambar Login/Dashboard
       </label>
       <input class="border p-2 w-full" type="file"/>
      </div>
      <div class="mb-4">
       <label class="block font-bold mb-2">
        Warna Header, Footer &amp; Badge
       </label>
       <select class="border p-2 w-full">
        <option>
         dark
        </option>
       </select>
      </div>
      <div class="mb-4">
       <label class="block font-bold mb-2">
        Warna Tabel &amp; Badge
       </label>
       <select class="border p-2 w-full">
        <option>
         red
        </option>
       </select>
      </div>
      <div class="flex space-x-4">
       <button class="bg-blue-600 text-white px-4 py-2 rounded flex items-center">
        <i class="fas fa-save mr-2">
        </i>
        Simpan
       </button>
       <button class="bg-red-600 text-white px-4 py-2 rounded flex items-center">
        <i class="fas fa-times mr-2">
        </i>
        Batal
       </button>
      </div>
     </div>
    </div>
   </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\qr-parking\resources\views/Admin/dataLatarBelakangMaster.blade.php ENDPATH**/ ?>