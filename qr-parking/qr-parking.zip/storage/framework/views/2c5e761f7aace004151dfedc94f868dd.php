<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Document</title>
</head>

<body>


    

    <?php $__env->startSection('content'); ?>
        <main class="mx-auto p-4" style="max-width: 90%;">
            <?php if(session('success')): ?>
                <script>
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil',
                        text: '<?php echo e(session('success')); ?>',
                        confirmButtonColor: '#3085d6',
                        confirmButtonText: 'OK'
                    });
                </script>
            <?php endif; ?>


            
            <div class="text-sm text-gray-600 mb-4">
                <a href="#" class="hover:underline">Dashboard</a> / <span>Jenis Kendaraan</span>
            </div>

            <h1 class="text-xl font-bold mb-4">DATA JENIS KENDARAAN <span class="text-red-600"><?php echo e($logo->nama_aplikasi); ?></span></h1>

            <div class="grid grid-cols-2 gap-4">
                
                <div class="bg-white p-4 rounded shadow">
                    <h2 class="text-lg font-bold border-b-2 border-red-600 pb-2 mb-4"><i class="fas fa-plus-circle"></i>
                        Form Tambah Data Jenis Kendaraan</h2>
                    <form action="<?php echo e(route('data.kendaraan.store')); ?>" method="POST" class="space-y-4">
                        <?php echo csrf_field(); ?>
                        <div class="mb-4">
                            <label class="block text-gray-700">Nama Kendaraan</label>
                            <input type="text" id="namaKendaraan" name="nama"
                                placeholder="Tuliskan Nama Kendaraan (Contoh: Mobil)" class="w-full p-2 border rounded">
                        </div>
                        <div class="mb-4">
                            <label class="block text-gray-700">Tarif Parkir Kendaraan</label>
                            <input type="number" name="tarif"
                                placeholder="Tuliskan Tarif Kendaraan (Contoh: 3000) Tulis Tanpa Tanda Baca"
                                class="w-full p-2 border rounded">
                        </div>
                        <div class="mb-4">
                            <label class="block text-gray-700">Keterangan Tarif Parkir Kendaraan</label>
                            <select name="keterangan" class="w-full p-2 border rounded">
                                <option value="Flat">Flat</option>
                                <option value="Per Jam">Per Jam</option>
                            </select>
                        </div>

                        <div class="flex space-x-4 mt-16">
                            <button type="submit"
                                class="bg-blue-600 text-white px-4 py-2 rounded flex items-center space-x-2">
                                <i class="fas fa-save"></i><span>Simpan</span>
                            </button>
                            <button type="reset"
                                class="bg-red-600 text-white px-4 py-2 rounded flex items-center space-x-2">
                                <i class="fas fa-times"></i><span>Batal</span>
                            </button>
                        </div>
                    </form>

                </div>

                
                <div class="bg-white p-4 rounded shadow">
                    <h2 class="text-lg font-bold border-b-2 border-red-600 pb-2 mb-4"><i class="fas fa-table"></i> Data
                        Tabel Jenis Kendaraan</h2>

                    <form method="GET" class="flex justify-between items-center mb-4">
                        <div>
                            <label>Show
                                <select name="perPage" onchange="this.form.submit()" class="border rounded p-1">
                                    <?php $__currentLoopData = [5, 10, 25, 50, 100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $limit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($limit); ?>"
                                            <?php echo e(request('perPage', 5) == $limit ? 'selected' : ''); ?>>
                                            <?php echo e($limit); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select> entries
                            </label>
                        </div>
                        <div>
                            <label>
                                Search:
                                <input type="search" name="search" value="<?php echo e(request('search')); ?>"
                                    class="border rounded p-1" placeholder="Cari...">
                            </label>
                        </div>
                    </form>


                    <table class="w-full border-collapse">
                        <thead>
                            <tr class="bg-red-600 text-white">
                                <th class="border p-2">NO.</th>
                                <th class="border p-2">JENIS KENDARAAN</th>
                                <th class="border p-2">TARIF PARKIR</th>
                                <th class="border p-2">KETERANGAN</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $jenisKendaraan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="bg-gray-100">
                                    <td class="border p-2 text-center">
                                        <div class="flex items-center justify-center space-x-2">
                                            <i class="fas fa-plus-circle text-blue-600 cursor-pointer toggle-action"
                                                data-id="<?php echo e($item->id); ?>"></i>
                                            <span> <?php echo e($loop->iteration + ($jenisKendaraan->firstItem() - 1)); ?>.</span>
                                        </div>
                                    </td>
                                    <td class="border p-2"><?php echo e($item->nama_kendaraan); ?></td>
                                    <td class="border p-2">Rp<?php echo e(number_format($item->tarif_parkir, 0, ',', '.')); ?></td>
                                    <td class="border p-2"><?php echo e($item->keterangan_tarif); ?></td>
                                </tr>
                                <tr class="action-row hidden" id="action-row-<?php echo e($item->id); ?>">
                                    <td colspan="4" class="border p-2 text-center">
                                        <button class="bg-yellow-400 text-white px-4 py-1 rounded mr-2 btn-edit"
                                            data-id="<?php echo e($item->id); ?>" data-nama="<?php echo e($item->nama_kendaraan); ?>"
                                            data-tarif="<?php echo e($item->tarif_parkir); ?>"
                                            data-keterangan="<?php echo e($item->keterangan_tarif); ?>">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>


                                        <div id="exportModal1-<?php echo e($item->id); ?>"
                                            class="hidden fixed inset-0 z-50 flex items-start justify-center bg-black bg-opacity-50 pt-24">

                                            <div class="bg-white rounded-lg shadow-lg w-full max-w-md">
                                                <div
                                                    class="bg-red-500 text-white text-lg font-semibold p-4 rounded-t-lg flex justify-between items-center">
                                                    <span><i class="fas fa-car"></i> Ubah Data Jenis Kendaraan</span>
                                                    <button class="text-white closeExportForm"
                                                        data-id="<?php echo e($item->id); ?>">
                                                        <i class="fas fa-times"></i>
                                                    </button>
                                                </div>
                                                <form id="editForm-<?php echo e($item->id); ?>"
                                                    action="<?php echo e(route('update', ['id' => $item->id])); ?>" method="POST">

                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <div class="p-6">
                                                        <div class="mb-4">
                                                            <label class="block text-gray-700 text-sm font-bold mb-2"
                                                                for="input-nama-<?php echo e($item->id); ?>">
                                                                Nama Kendaraan
                                                            </label>
                                                            <input
                                                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                                                id="input-nama-<?php echo e($item->id); ?>" type="text"
                                                                value="<?php echo e($item->nama_kendaraan); ?>"
                                                                name="nama_kendaraan">
                                                        </div>
                                                        <div class="mb-4">
                                                            <label class="block text-gray-700 text-sm font-bold mb-2"
                                                                for="input-tarif-<?php echo e($item->id); ?>">
                                                                Tarif Parkir Kendaraan
                                                            </label>
                                                            <input
                                                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                                                id="input-tarif-<?php echo e($item->id); ?>" type="text"
                                                                value="<?php echo e($item->tarif_parkir); ?>" name="tarif_parkir">
                                                        </div>
                                                        <div class="mb-6">
                                                            <label class="block text-gray-700 text-sm font-bold mb-2"
                                                                for="input-keterangan-<?php echo e($item->id); ?>">
                                                                Keterangan Tarif Parkir Kendaraan
                                                            </label>
                                                            <select
                                                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                                                id="input-keterangan-<?php echo e($item->id); ?>"
                                                                name="keterangan_tarif">
                                                                <option value="Flat"
                                                                    <?php echo e($item->keterangan_tarif == 'Flat' ? 'selected' : ''); ?>>
                                                                    Flat</option>
                                                                <option value="Per Jam"
                                                                    <?php echo e($item->keterangan_tarif == 'Per Jam' ? 'selected' : ''); ?>>
                                                                    Per Jam</option>
                                                                
                                                            
                                                                <!-- Tambahkan opsi lain sesuai kebutuhan -->
                                                            </select>
                                                        </div>

                                                        <div class="flex justify-end">
                                                            <button type="button"
                                                                class="bg-red-500 text-white font-bold py-2 px-4 rounded mr-2 flex items-center closeExportForm"
                                                                data-id="<?php echo e($item->id); ?>">
                                                                <i class="fas fa-times-circle mr-1"></i> Batal
                                                            </button>
                                                            <button type="submit"
                                                                class="bg-blue-500 text-white font-bold py-2 px-4 rounded flex items-center">
                                                                <i class="fas fa-save mr-1"></i> Simpan
                                                            </button>
                                                        </div>
                                                    </div>
                                                </form>

                                            </div>
                                        </div>


                                        <button class="bg-red-600 text-white px-4 py-1 rounded btn-hapus"
                                            data-id="<?php echo e($item->id); ?>" data-nama="<?php echo e($item->nama_kendaraan); ?>">
                                            <i class="fas fa-trash"></i> Hapus
                                        </button>
                                        <div id="confirmModal"
                                            class="hidden fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
                                            <div class="bg-white rounded-lg shadow-lg w-full max-w-sm">
                                                <div
                                                    class="bg-red-600 text-white text-lg font-semibold p-4 rounded-t-lg flex justify-between items-center">
                                                    <span><i class="fas fa-exclamation-triangle"></i> Konfirmasi
                                                        Hapus</span>
                                                    <button type="button" class="text-white" id="btnCloseHapus"><i
                                                            class="fas fa-times"></i></button>
                                                </div>
                                                <div class="p-6 text-center">
                                                    <p class="mb-4 text-gray-700">Apakah Anda yakin ingin menghapus <span
                                                            class="font-semibold" id="namaKendaraanHapus"></span>?</p>
                                                    <form action="<?php echo e(route('destroy', $item->id)); ?>" method="POST"
                                                        class="inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <div class="flex justify-center gap-3">
                                                            <button type="button"
                                                                class="bg-gray-400 hover:bg-gray-500 text-white px-4 py-2 rounded"
                                                                id="btnCancelHapus">Batal</button>
                                                            <button type="submit"
                                                                class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded">Hapus</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>


                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>


                    <div class="flex justify-between items-center mt-4">
                        <div>
                            Showing <?php echo e($jenisKendaraan->firstItem()); ?> to <?php echo e($jenisKendaraan->lastItem()); ?> of
                            <?php echo e($jenisKendaraan->total()); ?> entries
                        </div>
                        <div>
                            <?php echo e($jenisKendaraan->appends(request()->query())->links('vendor.pagination.custom')); ?>

                        </div>

                    </div>


                    <div class="mt-4 text-sm text-gray-600">
                        <p><i class="fas fa-exclamation-circle"></i> Mohon berhati-hati jika ingin menghapus data
                            kendaraan...</p>
                    </div>
                </div>
            </div>

            
            <!-- Modal Hapus -->





        </main>

        
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

        <script>
            document.querySelectorAll('.toggle-action').forEach(button => {
                button.addEventListener('click', () => {
                    const id = button.dataset.id;
                    const actionRow = document.getElementById(`action-row-${id}`);
                    actionRow.classList.toggle('hidden');
                });
            });
        </script>
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                const btnHapusList = document.querySelectorAll('.btn-hapus');
                const modal = document.getElementById('confirmModal');
                const formHapus = document.getElementById('formHapus');
                const namaSpan = document.getElementById('namaKendaraanHapus');
                const btnClose = document.getElementById('btnCloseHapus');
                const btnCancel = document.getElementById('btnCancelHapus');

                btnHapusList.forEach(btn => {
                    btn.addEventListener('click', function() {
                        const id = this.dataset.id;
                        const nama = this.dataset.nama;

                        // Ganti action form agar sesuai id

                        // Tampilkan nama kendaraan di teks modal
                        namaSpan.textContent = nama;

                        // Tampilkan modal
                        modal.classList.remove('hidden');
                    });
                });


                btnClose.addEventListener('click', () => {
                    modal.classList.add('hidden');
                });

                btnCancel.addEventListener('click', () => {
                    modal.classList.add('hidden');
                });
            });
        </script>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Tombol edit
                document.querySelectorAll('.btn-edit').forEach(button => {
                    button.addEventListener('click', function() {
                        const id = this.dataset.id;
                        const nama = this.dataset.nama;
                        const tarif = this.dataset.tarif;
                        const keterangan = this.dataset.keterangan;

                        // Cari modal sesuai id
                        const modal = document.getElementById(`exportModal1-${id}`);
                        if (!modal) return console.error('Modal tidak ditemukan:', id);

                        // Cari input dan form di modal
                        const inputNama = document.getElementById(`input-nama-${id}`);
                        const inputTarif = document.getElementById(`input-tarif-${id}`);
                        const inputKeterangan = document.getElementById(`input-keterangan-${id}`);
                        const form = document.getElementById(`editForm-${id}`);

                        if (!inputNama || !inputTarif || !inputKeterangan || !form) {
                            return console.error('Input atau form tidak lengkap di modal:', id);
                        }

                        // Set nilai input
                        inputNama.value = nama;
                        inputTarif.value = tarif;
                        inputKeterangan.value = keterangan;

                        // Set action form

                        // Tampilkan modal
                        modal.classList.remove('hidden');
                    });
                });

                // Tombol close modal (bisa dari icon close atau tombol batal)
                document.querySelectorAll('.closeExportForm').forEach(button => {
                    button.addEventListener('click', function() {
                        const id = this.dataset.id;
                        const modal = document.getElementById(`exportModal1-${id}`);
                        if (modal) {
                            modal.classList.add('hidden');
                        }
                    });
                });
            });
        </script>
    <?php $__env->stopSection(); ?>
</body>

</html>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\qr-parking\resources\views/Admin/dataJenisKendaraan.blade.php ENDPATH**/ ?>