
<?php $__env->startSection('content'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        <?php if(session('success')): ?>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: '<?php echo e(session('success')); ?>',
                confirmButtonColor: '#3085d6',
                confirmButtonText: 'OK'
            });
        <?php endif; ?>
    </script>

    <style>
        .uppercase-input {
            text-transform: uppercase;
        }

        .uppercase-input::placeholder {
            text-transform: none;
        }
    </style>



    <div class="max-w-7xl mx-auto mt-4 px-4">

        <div class="bg-white p-6 rounded shadow-md">

            <h2 class="text-xl font-bold mb-4">APLIKASI PARKIR KENDARAAN <span
                    class="text-red-500"><?php echo e($logo->nama_aplikasi); ?></span></h2>
            <div class="grid grid-cols-2 gap-4">
                <div class="flex flex-col">
                    <div class="border border-red-500 p-4 rounded flex-grow relative">
                        <h3 class="text-lg font-bold mb-4"><i class="fas fa-plus-circle"></i> Form Tambah Data Parkir Masuk
                        </h3>

                        <!-- FORM BIASA -->
                        <form id="formData" method="POST" action="<?php echo e(route('dataparkir.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="grid grid-cols-2 gap-4 mb-4">
                                <div>
                                    <label class="block text-gray-700">Kode Parkir Kendaraan</label>
                                    <input type="text" name="kode_parkir" id="kodeParkirInput"
                                        class="w-full p-2 border rounded" value="<?php echo e($kode); ?> " readonly>
                                </div>
                                <div>
                                    <label class="block text-gray-700">Jenis Kendaraan</label>
                                    <select name="jenis_kendaraan" class="w-full p-2 border rounded">
                                        <option value="">Pilih Jenis Kendaraan</option>
                                        <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_kendaraan); ?></option>
                                            <!-- Tambahkan jenis lain jika ada -->
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="mb-4">
                                <label class="block text-gray-700">Plat Nomor Kendaraan</label>
                                <input type="text" name="plat_nomor" class="w-full p-2 border rounded uppercase-input"
                                    placeholder="Contoh: DB 463 JO">
                            </div>
                            <div class="mb-4">
                                <label class="block text-gray-700">Tipe/Merek Kendaraan</label>
                                <input type="text" name="tipe_merek" class="w-full p-2 border rounded"
                                    placeholder="Contoh: Avanza / Toyota">
                            </div>
                            <div class="mb-4">
                                <label class="block text-gray-700">Warna Kendaraan</label>
                                <input type="text" name="warna" class="w-full p-2 border rounded"
                                    placeholder="Contoh: Hijau Daun">
                            </div>
                            <div class="flex space-x-4 mt-20">
                                <button onclick="getLocationAndSubmit()" type="submit"
                                    class="bg-blue-500 text-white px-4 py-2 rounded flex items-center">
                                    <i class="fas fa-save mr-2"></i> Simpan
                                </button>
                                <button type="reset" class="bg-red-500 text-white px-4 py-2 rounded flex items-center">
                                    <i class="fas fa-times mr-2"></i> Batal
                                </button>
                                <button type="button" id="btnBarcode"
                                    class="absolute right-4 bg-green-500 text-white px-4 py-2 rounded flex items-center">
                                    <i class="fas fa-barcode mr-2"></i> Gunakan Barcode
                                </button>
                            </div>

                            <!-- Field lainnya -->

                            <input type="hidden" name="latitude" id="latitude">
                            <input type="hidden" name="longitude" id="longitude">


                        </form>


                        <!-- TAMPILAN BARCODE -->
                        <div id="barcodeSection" class="hidden text-center">
                            <img src="<?php echo e(asset('img/qr.png')); ?>" alt="" class="w-80 h-80 m-auto">


                            <p class="mt-4 font-bold text-gray-800">Scan Disini dengan <span id="kodeBarcodeText">Mobile
                                    Apps</span></p>
                            <button type="button" id="btnKembaliForm"
                                class="mt-4 bg-blue-500 text-white px-4 py-2 rounded">
                                <i class="fas fa-arrow-left mr-2"></i> Kembali ke Form
                            </button>
                        </div>
                    </div>



                </div>
                <div>
                    <div class="border border-gray-300 p-4 rounded h-full">
                        <h3 class="text-lg font-bold mb-4"><i class="fas fa-table"></i> Data Tabel Parkir Masuk Hari Ini
                        </h3>
                        <form method="GET" class="flex justify-between items-center mb-4">
                            <div>
                                <label>Show
                                    <select name="perPage" onchange="this.form.submit()" class="border rounded p-1">
                                        <?php $__currentLoopData = [5, 10, 25, 50, 100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $limit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($limit); ?>"
                                                <?php echo e(request('perPage', 5) == $limit ? 'selected' : ''); ?>>
                                                <?php echo e($limit); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select> entries
                                </label>
                            </div>
                            <div>
                                <label>
                                    Search:
                                    <input type="search" name="search" value="<?php echo e(request('search')); ?>"
                                        class="border rounded p-1" placeholder="Cari...">
                                </label>
                            </div>
                        </form>
                        <table class="w-full border-collapse">
                            <thead>
                                <tr class="bg-red-500 text-white">
                                    <th class="border p-2">No.</th>
                                    <th class="border p-2">Kode Parkir</th>
                                    <th class="border p-2">Plat Nomor</th>
                                    <th class="border p-2">Jenis Kendaraan</th>
                                    <th class="border p-2">Waktu Masuk</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $jenisKendaraan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="bg-gray-100">
                                        <td class="border p-2 text-center">
                                            <?php echo e($loop->iteration + $jenisKendaraan->firstItem() - 1); ?></td>
                                        <td class="border p-2"><?php echo e($item->kode_parkir); ?></td>
                                        <td class="border p-2"><?php echo e($item->platNomor->plat_nomor); ?></td>
                                        <td class="border p-2"><?php echo e($item->tipeKendaraan->jenis->nama_kendaraan); ?></td>

                                        <td class="border p-2">
                                            <div class="bg-gray-200 p-1 rounded text-center">
                                                <div><?php echo e($item->waktu_masuk); ?></div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="flex justify-between items-center mt-4">
                            <div>
                                Showing <?php echo e($jenisKendaraan->firstItem()); ?> to <?php echo e($jenisKendaraan->lastItem()); ?> of
                                <?php echo e($jenisKendaraan->total()); ?> entries
                            </div>
                            <div>
                                <?php echo e($jenisKendaraan->appends(request()->query())->links('vendor.pagination.custom')); ?>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<!-- JsBarcode CDN -->


<script>
    window.onload = function() {
        document.getElementById('btnBarcode').addEventListener('click', function() {
            const kode = document.getElementById('kodeParkirInput').value;

            const barcodeSection = document.getElementById('barcodeSection');
            const formData = document.getElementById('formData');

            barcodeSection.classList.remove('hidden');
            formData.classList.add('hidden');

            JsBarcode("#barcodeCanvas", kode, {
                format: "CODE128",
                displayValue: true,
                fontSize: 18,
                lineColor: "#000",
                width: 2,
                height: 80
            });

            document.getElementById('kodeBarcodeText').textContent = kode;
        });

        document.getElementById('btnKembaliForm').addEventListener('click', function() {
            document.getElementById('barcodeSection').classList.add('hidden');
            document.getElementById('formData').classList.remove('hidden');
        });
    };

    function getLocationAndSubmit() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(success, error);
        } else {
            alert("Geolocation tidak didukung oleh browser ini.");
        }
    }

    function success(position) {
        const lat = position.coords.latitude;
        const lon = position.coords.longitude;

        // Isi nilai latitude & longitude di form hidden input
        document.getElementById('latitude').value = lat;
        document.getElementById('longitude').value = lon;

        // Submit form setelah isi lokasi
        document.getElementById('formData').submit();
    }

    function error() {
        alert("Gagal mendapatkan lokasi. Mohon izinkan akses lokasi browser.");
    }
</script>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\qr-parking\resources\views/Admin/dataMasuk.blade.php ENDPATH**/ ?>