<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('attendance_rules', function (Blueprint $table) {
            $table->id();
            $table->string('rule_name');
            $table->time('start_time');
            $table->time('end_time');
            $table->integer('late_tolerance')->default(15);
            $table->integer('early_tolerance')->default(15);
            $table->integer('max_distance')->default(100);
            $table->decimal('work_location_latitude', 10, 8);
            $table->decimal('work_location_longitude', 11, 8);
            $table->string('work_location_name');
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('attendance_rules');
    }
};
