<?php
// database/migrations/<timestamp>_create_topup_transactions_table.php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('topup_transactions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->onDelete('cascade');
            $table->string('order_id')->unique(); // Unique ID for Midtrans
            $table->decimal('nominal', 15, 2);
            $table->decimal('biaya_admin', 15, 2);
            $table->decimal('total_dibayar', 15, 2);
            $table->string('metode_pembayaran');
            $table->string('status')->default('pending'); // pending, success, failed, expire, etc.
            $table->text('midtrans_snap_token')->nullable();
            $table->text('midtrans_redirect_url')->nullable();
            $table->json('transaction_details')->nullable(); // Store full Midtrans response if needed
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('topup_transactions');
    }
};
