<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Kendaraan extends Model
{
    use HasFactory;

    protected $table = 'kendaraan'; // pastikan sesuai nama tabel di database kamu

    protected $fillable = [
        'id',
        'id_jenis',
        'merk_kendaraan',
        'plat_nomor',
        'warna',
        'user_id',
        'is_aktif',
        'is_tarif',
    ];

    /**
     * Relasi ke user
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Relasi ke jenis kendaraan (jika ada tabel jenis_kendaraans)
     */
    public function jenis()
    {
        return $this->belongsTo(Tipe_kendaraan::class, 'id_jenis');
    }
    public function tarif()
    {
        return $this->belongsTo(Tipe_kendaraan::class, 'id_tarif');
    }

    public function merkDipakai()
    {
        return $this->hasMany(DataParkir::class, 'id_merk_kendaraan');
    }

    public function platDipakai()
    {
        return $this->hasMany(DataParkir::class, 'id_plat_nomor');
    }

    public function tipeDipakai()
    {
        return $this->hasMany(DataParkir::class, 'id_tipe_kendaraan');
    }

    public function warnaDipakai()
    {
        return $this->hasMany(DataParkir::class, 'id_warna_kendaraan');
    }
}
