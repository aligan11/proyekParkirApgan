<?php

namespace App\Http\Middleware\MiddlewareWeb;

use Closure;
use Illuminate\Contracts\Session\Session;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class loggedIn
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        $loginStatus = Session()->get('loginStatus');
        if ($loginStatus == FALSE || !$loginStatus) {
            return redirect()->route('home');
        }
        return $next($request);
    }
}
