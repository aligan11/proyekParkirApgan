<?php

namespace App\Http\Controllers;

use App\Http\Requests\LoginRequest;
use App\Http\Requests\RegisterRequest;
use App\Http\Requests\listNamaRequest;
use App\Http\Requests\listNamaRequestUpdate;
use App\Http\Resources\nyubeResource;
use App\Http\Resources\UserResource;
use App\Models\nyubeUser;
use App\Models\User;

use App\Traits\ApiResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;


class profileController extends Controller
{
    use ApiResponse;
    /**
     * @param \App\Http\Requests\RegisterRequest $request
     * @return mixed|\Illuminate\Http\JsonResponse
     */

    public function updateUserParking(listNamaRequestUpdate $request, $id_users)
    {
        $data = $request->validated();

        $user = User::findOrFail($id_users);

        if (isset($data['nama_lengkap'])) {
            $user->nama_lengkap = $data['nama_lengkap'];
        }

        if (isset($data['username'])) {
            $user->username = $data['username'];
        }

        if (isset($data['password'])) {
            $user->password = Hash::make($data['password']);
        }

        if ($request->hasFile('foto_users')) {
            $fotoPath = $request->file('foto_users')->store('uploads/foto_user', 'public');
            $user->foto_users = $fotoPath;
        }

        $user->save();

        return response()->json([
            'status' => 'success',
            'message' => 'User berhasil diupdate',
            'data' => $user,
        ]);
    }


    public function showIdUser(string $id)
    {
        $topups = User::where('id_users', $id)->get();

        if ($topups->isEmpty()) {
            return $this->errorResponse('Data tidak ditemukan.', 404);
        }
        return $this->successResponse([
            'data' => $topups,
        ], 'Berhasil mendapatkan data.');
    }
}
