<?php

// app/Http/Controllers/AuthController.php
namespace App\Http\Controllers\ControllersWeb;

use App\Rules\loginCheck;
use Illuminate\Contracts\Session\Session;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class AuthController extends Controller
{
    public function loginProcess(Request $request)
    {
        // Validasi input
        // dd($request->all());
        $request->validate([
            'username' => 'required|email',
            'role' => 'required',
            'password' => ['required', new loginCheck($request)]
        ]);


        return redirect()->route('dashboard');
    }

    public function logout(Request $request)
    {
        session()->flush();

        return redirect()->route('home');
    }
}
