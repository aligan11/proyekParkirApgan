<?php

namespace App\Http\Controllers\ControllersWeb;

use App\Models\DataParkir;
use App\Models\Parkir;
use App\Models\PropertyAplikasi;
use App\Models\Tipe_kendaraan;
use Illuminate\Http\Request;

class DashboardController extends Controller
{

    public function app()
    {
        $logo = PropertyAplikasi::first();
        return view('app.blade.php', compact('logo'));
    }
    //
    public function index()
    {
        // Kamu bisa kirim data ke view di sini kalau butuh.
        return view('Admin.index');
    }


    public function tampilDataKeluar(Request $request)
    {
        $jenis = Tipe_kendaraan::all();

        $perPage = $request->input('perPage', 5); // default 5
        $search = $request->input('search');

        // Mulai query + load relasi
        $query = DataParkir::with([
            'user',
            'merkKendaraan',
            'platNomor',
            'tipeKendaraan',
            'warnaKendaraan',
            'tarif',
        ]);

        // Jika ada pencarian
        if ($search) {
            $query->where('plat_nomor', 'like', '%' . $search . '%');
        }

        // Pagination + query string
        $jenisKendaraan = $query->latest()->paginate($perPage)->withQueryString();

        return view('Admin.dataKeluar', compact('jenis', 'perPage', 'search', 'jenisKendaraan'));
    }

    public function confirmDataKeluar()
    {
        return view('Admin.konfirmasiDataKeluar');
    }
    public function tampilDataParkir(Request $request)
    {
        $perPage = $request->input('perPage', 5); // default 5
        $search = $request->input('search');
        $sort = $request->input('sort', 'desc'); // default 'desc' (terbaru)

        $query = DataParkir::query();

        if ($search) {
            $query->whereHas('platNomor', function ($q) use ($search) {
                $q->where('plat_nomor', 'like', '%' . $search . '%');
            })->with('jenis', 'tarif');
        }

        $jenisKendaraan = $query->orderBy('waktu_masuk', $sort)->paginate($perPage)->withQueryString();

        return view('Admin.dataParkirMasukRekapitulasi', compact('perPage', 'search', 'jenisKendaraan', 'sort'));
    }

    public function tampilDataParkirKeluar(Request $request)
    {
        $perPage = $request->input('perPage', 5); // default 5
        $search = $request->input('search');
        $sort = $request->input('sort', 'desc'); // default 'desc' (terbaru)

        $query = DataParkir::query();

        if ($search) {
            $query->whereHas('platNomor', function ($q) use ($search) {
                $q->where('plat_nomor', 'like', '%' . $search . '%');
            })->with('jenis', 'tarif');
        }

        $jenisKendaraan = $query->orderBy('waktu_masuk', $sort)->paginate($perPage)->withQueryString();

        return view('Admin.dataParkirKeluarRekapitulasi', compact('perPage', 'search', 'jenisKendaraan', 'sort'));
    }

    public function tampilDataParkirGabungan(Request $request)
    {
        $perPage = $request->input('perPage', 5); // default 5
        $search = $request->input('search');
        $sort = $request->input('sort', 'desc'); // default 'desc' (terbaru)

        $query = DataParkir::query();

        if ($search) {
            $query->whereHas('platNomor', function ($q) use ($search) {
                $q->where('plat_nomor', 'like', '%' . $search . '%');
            })->with('jenis', 'tarif');
        }

        $jenisKendaraan = $query->orderBy('waktu_masuk', $sort)->paginate($perPage)->withQueryString();

        return view('Admin.dataParkirGabunganRekapitulasi', compact('perPage', 'search', 'jenisKendaraan', 'sort'));
    }
    public function tampilDataAplikasi()
    {
        $property = PropertyAplikasi::first();

        return view('Admin.dataAplikasiMaster', compact('property'));
    }

    public function tampilDataKendaraan()
    {
        return view('Admin.dataJenisKendaraan');
    }

    public function update(Request $request)
    {
        $request->validate([
            'nama_aplikasi' => 'required|string|max:255',
            'kode_parkir' => 'required|string|max:50',
            'nama_perusahaan' => 'nullable|string|max:255',
            'alamat' => 'nullable|string|max:255',
            'email' => 'nullable|email',
            'telepon' => 'nullable|string|max:20',
            'logo' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        $property = PropertyAplikasi::first();

        if (!$property) {
            $property = new PropertyAplikasi();
        }

        $property->nama_aplikasi = $request->nama_aplikasi;
        $property->kode_parkir = $request->kode_parkir;
        $property->owner_parkir = $request->nama_perusahaan;
        $property->alamat_perusahaan = $request->alamat;
        $property->email_perusahaan = $request->email;
        $property->no_perusahaan = $request->telepon;

        if ($request->hasFile('logo')) {
            $file = $request->file('logo');
            $filename = time() . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('img'), $filename);
            $property->logo_aplikasi = $filename;
        }

        $property->save();

        return redirect()->route('data.aplikasi')->with('success', 'Data aplikasi berhasil diperbarui.');
    }

    public function reset()
    {
        $property = PropertyAplikasi::first();

        // Set data default
        $property->nama_aplikasi = 'GANPARKING';
        $property->kode_parkir = 'PARKIR';
        $property->owner_parkir = 'Gan Company';
        $property->alamat_perusahaan = 'Jl. Default No. 1, Jakarta';
        $property->email_perusahaan = 'info@ganparking.com';
        $property->no_perusahaan = '08123456789';

        // Hapus logo jika ada
        if ($property->logo_aplikasi) {
            $filePath = public_path('img/' . $property->logo_aplikasi);
            if (file_exists($filePath)) {
                unlink($filePath);
            }

            $property->logo_aplikasi = null;
        }

        $property->save();

        return redirect()->back()->with('success', 'Data aplikasi telah dikembalikan ke pengaturan default.');
    }


    public function tampilDataBg()
    {
        return view('Admin.dataLatarBelakangMaster');
    }

    public function tampilDataUsers()
    {
        return view('Admin.dataUsersMaster');
    }
}
