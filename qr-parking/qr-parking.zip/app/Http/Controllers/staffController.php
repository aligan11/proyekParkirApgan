<?php

namespace App\Http\Controllers;

use App\Http\Requests\listNamaRequestUpdate;
use App\Models\DataParkir;
use App\Models\User;
use Illuminate\Http\Request;
use App\Traits\ApiResponse;
use Illuminate\Support\Facades\Hash;

class staffController extends Controller
{
    //
    use ApiResponse;

    public function showByPlat($plat)
    {
        $dataParkir = DataParkir::whereHas('platNomor', function ($query) use ($plat) {
            $query->where('plat_nomor', $plat);
        })->get();

        if ($dataParkir->isEmpty()) {
            return $this->errorResponse('Data tidak ditemukan untuk plat: ' . $plat, 404);
        }

        $data = $dataParkir->map(function ($item) {
            return [
                'kode_parkir'     => $item->kode_parkir,
                'waktu_masuk'     => $item->waktu_masuk,
                'lokasi'          => $item->lokasi,
                'status'          => $item->status,

                // Relasi
                'merk_kendaraan'  => optional($item->merkKendaraan)->merk_kendaraan ?? '-',
                'plat_nomor'      => optional($item->platNomor)->plat_nomor ?? '-',
                'tipe_kendaraan'  => optional($item->tipeKendaraan->jenis)->nama_kendaraan ?? '-',
                'warna_kendaraan' => optional($item->warnaKendaraan)->warna ?? '-',
                'tarif'           => optional($item->tarif)->tarif_parkir ?? '-',
            ];
        });

        return $this->successResponse([
            'data' => $data
        ], 'Berhasil mendapatkan data berdasarkan plat nomor.');
    }

    public function updateUserParking(listNamaRequestUpdate $request, $id_users)
    {
        $data = $request->validated();

        $user = User::findOrFail($id_users);

        if (isset($data['nama_lengkap'])) {
            $user->nama_lengkap = $data['nama_lengkap'];
        }

        if (isset($data['username'])) {
            $user->username = $data['username'];
        }

        if (isset($data['password'])) {
            $user->password = Hash::make($data['password']);
        }

        if ($request->hasFile('foto_users')) {
            $fotoPath = $request->file('foto_users')->store('uploads/foto_user', 'public');
            $user->foto_users = $fotoPath;
        }

        $user->save();

        return response()->json([
            'status' => 'success',
            'message' => 'User berhasil diupdate',
            'data' => $user,
        ]);
    }
}
