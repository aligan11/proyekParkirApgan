<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <!-- Tailwind & AlpineJS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>

    <!-- Fonts & Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet" />

    <style>
        body {
            font-family: 'Roboto', sans-serif;
        }
    </style>
</head>

<body class="bg-gray-100">
    <!-- Header -->
    <header class="bg-gray-800 text-white px-12 py-4 flex justify-between items-center">
        <div class="flex items-center space-x-8">
            <!-- Logo -->
            <div class="flex items-center space-x-2">
                @if ($logo_aplikasi)
                    <img src="{{ asset('img/' . $logo_aplikasi) }}" alt="Logo" class="w-8 h-8 rounded-full">
                @else
                    <i class="fas fa-car"></i>
                @endif
                <span class="font-bold text-lg">{{ $nama_aplikasi ?? 'GANPARKING' }}</span>

            </div>

            <!-- Navigation -->
            <nav class="flex space-x-6 text-sm">
                <a href="{{ route('dashboard') }}" class="flex items-center space-x-1 hover:text-blue-400 transition">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
                <a href="{{ route('dataparkir.index') }}"
                    class="flex items-center space-x-1 hover:text-blue-400 transition">
                    <i class="fas fa-sign-in-alt"></i>
                    <span>Parkir Masuk</span>
                </a>
                <a href="{{ route('parkir.keluar') }}"
                    class="flex items-center space-x-1 hover:text-blue-400 transition">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Parkir Keluar</span>
                </a>

                <!-- Dropdown: Data Parkir -->
                <div x-data="{ open: false }" class="relative">
                    <button @click="open = !open" @click.away="open = false"
                        class="flex items-center space-x-1 hover:text-blue-400 focus:outline-none transition">
                        <i class="fas fa-database"></i>
                        <span>Data Parkir</span>
                        <i class="fas fa-chevron-down text-xs ml-1"></i>
                    </button>
                    <div x-show="open" x-transition
                        class="absolute mt-2 w-56 bg-white text-gray-800 rounded shadow z-10">
                        <a href="{{ route('data.parkir.masuk') }}" class="block px-4 py-2 hover:bg-gray-100 text-sm"><i
                                class="fas fa-sign-in-alt mr-2"></i>Parkir Masuk</a>
                        <a href="{{ route('data.parkir.keluar') }}" class="block px-4 py-2 hover:bg-gray-100 text-sm"><i
                                class="fas fa-sign-out-alt mr-2"></i>Parkir Keluar</a>
                        <a href="{{ route('data.parkir.gabungan') }}"
                            class="block px-4 py-2 hover:bg-gray-100 text-sm"><i
                                class="fas fa-database mr-2"></i>Gabungan</a>
                    </div>
                </div>

                <!-- Dropdown: Master Data -->
                <div x-data="{ open: false }" class="relative">
                    <button @click="open = !open" @click.away="open = false"
                        class="flex items-center space-x-1 hover:text-blue-400 focus:outline-none transition">
                        <i class="fas fa-cogs"></i>
                        <span>Master Data</span>
                        <i class="fas fa-chevron-down text-xs ml-1"></i>
                    </button>
                    <div x-show="open" x-transition
                        class="absolute mt-2 w-56 bg-white text-gray-800 rounded shadow z-10">
                        <a href="{{ route('data.aplikasi') }}" class="block px-4 py-2 hover:bg-gray-100 text-sm">
                            <i class="fas fa-cogs mr-2"></i>Data Aplikasi
                        </a>
                        <a href="{{ route('data.kendaraan') }}" class="block px-4 py-2 hover:bg-gray-100 text-sm">
                            <i class="fas fa-car mr-2"></i>Jenis Kendaraan
                        </a>
                       
                        <a href="{{ route('admin.create') }}" class="block px-4 py-2 hover:bg-gray-100 text-sm">
                            <i class="fas fa-user-plus mr-2"></i>Tambah Admin
                        </a>
                        <a href="{{ route('admin.createUser') }}" class="block px-4 py-2 hover:bg-gray-100 text-sm">
                            <i class="fas fa-user-plus mr-2"></i>Tambah User
                        </a>
                        <a href="{{ route('admin.createStaff') }}" class="block px-4 py-2 hover:bg-gray-100 text-sm">
                            <i class="fas fa-user-plus mr-2"></i>Tambah Staff
                        </a>
                        <a href="{{ route('topup-parkir.index') }}" class="block px-4 py-2 hover:bg-gray-100 text-sm">
                            <i class="fas fa-coins mr-2"></i>Tambah Paket Topup
                        </a>

                    </div>
                </div>
            </nav>
        </div>

        <!-- Profile Menu -->
        <div class="relative" x-data="{ open: false }">
            <div class="flex items-center space-x-3 cursor-pointer" @click="open = !open">
                <span class="text-sm font-medium">{{ session('adminData')->nama_lengkap }}</span>
                <img src="{{ asset(session('adminData')->foto_admin) }}" alt="Foto Admin"
                    class="w-8 h-8 rounded-full border-2 border-white shadow">
            </div>
            <div x-show="open" @click.away="open = false"
                class="absolute right-0 mt-2 w-40 bg-white border rounded-lg shadow z-50" x-transition>
                <a href="/profile" class="block px-4 py-2 text-sm hover:bg-gray-100 text-gray-700">View Profile</a>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit"
                        class="w-full text-left px-4 py-2 text-sm hover:bg-gray-100 text-gray-700">Logout</button>
                </form>
            </div>
        </div>
    </header>

    <!-- Content Section -->
    @yield('content')
</body>

</html>
