@extends('app')
@section('content')
    <main class="mx-auto" style="max-width: 90%;">

        @if (session('success'))
            <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
            <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>

            <script>
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil',
                    text: "{{ session('success') }}",
                    timer: 2500,
                    showConfirmButton: false,
                });
            </script>
        @endif

        <!-- Main Content -->
        <div class="flex flex-col md:flex-row justify-center px-4 py-4">
            <!-- Form Section -->
            <div class="bg-white shadow-md rounded-lg p-6 m-4 w-full md:w-1/2 border-t-2 border-red-500 border-opacity-50">
                <h2 class="text-lg font-bold mb-6 flex items-center border-b border-gray-300 pb-2">
                    <i class="fas fa-user mr-2 text-black-500 text-xl"></i>
                    Form Tambah User
                </h2>
                <form action="{{ route('admin.storeUser') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

                        <div>
                            <label class="block text-sm font-semibold text-gray-900 mb-1">Nama Lengkap</label>
                            <input type="text" name="nama_lengkap" value="" placeholder="Masukkan nama lengkap"
                                class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500" />
                            @error('nama_lengkap')
                                <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                            @enderror
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-900 mb-1">Photo</label>
                            <input type="file" name="photo"
                                class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500" />
                            @error('photo')
                                <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                            @enderror
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-900 mb-1">Jenis Kelamin</label>
                            <select name="jenis_kelamin"
                                class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500">
                                <option value="" disabled {{ old('jenis_kelamin') ? '' : 'selected' }}>Pilih jenis
                                    kelamin</option>
                                <option value="Laki-laki" {{ old('jenis_kelamin') == 'Laki-laki' ? 'selected' : '' }}>
                                    Laki-laki</option>
                                <option value="Perempuan" {{ old('jenis_kelamin') == 'Perempuan' ? 'selected' : '' }}>
                                    Perempuan</option>
                            </select>
                            @error('jenis_kelamin')
                                <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                            @enderror
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-900 mb-1">Handphone</label>
                            <input type="text" name="handphone" value="{{ old('handphone') }}"
                                placeholder="Contoh: 081234567890"
                                class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500" />
                            @error('handphone')
                                <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                            @enderror
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-900 mb-1">Email (Username)</label>
                            <input type="email" name="username" value="{{ old('username') }}"
                                placeholder="Tuliskan alamat email aktif"
                                class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500" />
                            @error('username')
                                <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                            @enderror
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-900 mb-1">Password</label>
                            <input type="password" name="password" placeholder="Password default: 123456"
                                class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500" />
                            @error('password')
                                <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                            @enderror
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-900 mb-1">Konfirmasi Password</label>
                            <input type="password" name="password" placeholder="Password default: 123456"
                                class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500" />
                            @error('password')
                                <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                            @enderror
                        </div>

                    </div>

                    <div class="mt-6">
                        <label class="block text-sm font-semibold text-gray-900 mb-1">Alamat</label>
                        <textarea name="alamat" placeholder="Masukkan alamat lengkap"
                            class="block w-full px-3 py-3 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500"
                            rows="4">{{ old('alamat') }}</textarea>
                        @error('alamat')
                            <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="flex justify-end mt-6">
                        <button type="submit"
                            class="bg-blue-500 text-white px-5 py-2 rounded-md mr-3 flex items-center hover:bg-blue-600 transition duration-200">
                            <i class="fas fa-save mr-2"></i>
                            Simpan
                        </button>
                        <a href="{{ url()->previous() }}"
                            class="bg-red-500 text-white px-5 py-2 rounded-md flex items-center hover:bg-red-600 transition duration-200">
                            <i class="fas fa-times mr-2"></i>
                            Batal
                        </a>
                    </div>
                </form>
            </div>

            <!-- Data Table Section -->
            <div class="bg-white shadow-md rounded-lg p-6 m-4 w-full md:w-1/2">
                <h2 class="text-lg font-bold mb-4 flex items-center">
                    <i class="fas fa-table mr-2"></i>
                    Data Tabel Users
                </h2>
                <div class="flex justify-between items-center mb-4">
                    <div>
                        <label class="text-sm">
                            Show
                            <select class="border-gray-300 rounded-md shadow-sm">
                                <option>10</option>
                            </select>
                            entries
                        </label>
                    </div>
                    <div>
                        <label class="text-sm">
                            Search:
                            <input class="border-gray-300 rounded-md shadow-sm" type="text" />
                        </label>
                    </div>
                </div>
                <table class="min-w-full bg-white">
                    <thead>
                        <tr class="bg-red-500 text-white">
                            <th class="py-2 px-4">No.</th>
                            <th class="py-2 px-4">Nama</th>
                            <th class="py-2 px-4">Email</th>
                            <th class="py-2 px-4">Password</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($users as $index => $user)
                            <tr class="border-b text-center">
                                <td class="border p-2 text-center flex items-center justify-center space-x-2">
                                    <i class="fas fa-plus-circle text-blue-600 cursor-pointer toggle-action"
                                        data-id="{{ $user }}"></i>
                                    <span>{{ $loop->iteration }}.</span>
                                </td>
                                <td class="py-2 px-4">{{ $user->nama_lengkap }}</td>
                                <td class="py-2 px-4">{{ $user->username }}</td>
                                <td class="py-2 px-4">********</td>
                            </tr>
                            <tr class="action-row hidden" id="action-row-{{ $user }}">
                                <td colspan="4" class="border p-2 text-center">
                                    <button onclick="openEditModal({{ $user->id_users }})"
                                        class="bg-yellow-400 text-white px-4 py-1 rounded mr-2 btn-edit">
                                        <i class="fas fa-edit"></i> Edit
                                    </button>
                                    <button class="bg-red-600 text-white px-4 py-1 rounded btn-hapus">
                                        <i class="fas fa-trash"></i> Hapus
                                    </button>
                                </td>
                                <!-- Modal Edit -->
                                <div id="editModal"
                                    class="fixed inset-0 z-50 hidden bg-black bg-opacity-50 flex items-center justify-center">
                                    <div class="bg-white rounded-lg shadow-lg p-6 w-full max-w-2xl relative">
                                        <!-- Tombol Close -->
                                        <button onclick="closeEditModal()"
                                            class="absolute top-2 right-2 text-gray-500 hover:text-gray-800">
                                            <i class="fas fa-times"></i>
                                        </button>

                                        <!-- Judul -->
                                        <h2 class="text-xl font-semibold mb-4 text-gray-800 border-b pb-2">Edit Data User
                                        </h2>

                                        <form id="editUserForm" action="admin.editUser" method="POST"
                                            enctype="multipart/form-data">
                                            @csrf
                                            @method('PUT')
                                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                                <input type="hidden" id="edit_id_users" name="id_users">

                                                <div>
                                                    <label class="block text-sm font-semibold text-gray-900 mb-1">Nama
                                                        Lengkap</label>
                                                    <input type="text" id="edit_nama_lengkap" name="nama_lengkap1"
                                                        value="" placeholder="Masukkan nama lengkap"
                                                        class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500" />
                                                    @error('nama_lengkap')
                                                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                                                    @enderror
                                                </div>



                                                <div>
                                                    <label class="block text-sm font-semibold text-gray-900 mb-1">Jenis
                                                        Kelamin</label>
                                                    <select name="jenis_kelamin2"
                                                        class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500">
                                                        <option value="" disabled
                                                            {{ old('jenis_kelamin') ? '' : 'selected' }}>Pilih jenis
                                                            kelamin</option>
                                                        <option value="Laki-laki"
                                                            {{ old('jenis_kelamin') == 'Laki-laki' ? 'selected' : '' }}>
                                                            Laki-laki</option>
                                                        <option value="Perempuan"
                                                            {{ old('jenis_kelamin') == 'Perempuan' ? 'selected' : '' }}>
                                                            Perempuan</option>
                                                    </select>
                                                    @error('jenis_kelamin')
                                                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                                                    @enderror
                                                </div>

                                                <div>
                                                    <label class="block text-sm font-semibold text-gray-900 mb-1">No
                                                        Handphone</label>
                                                    <input id="edit_no_hp" type="text" name="handphone1"
                                                        value="{{ old('handphone') }}" placeholder="Contoh: 081234567890"
                                                        class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500" />
                                                    @error('handphone')
                                                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                                                    @enderror
                                                </div>

                                                <div>
                                                    <label class="block text-sm font-semibold text-gray-900 mb-1">Email
                                                        (Username)
                                                    </label>
                                                    <input id="edit_email" type="email" name="username1"
                                                        value="{{ old('username') }}"
                                                        placeholder="Tuliskan alamat email aktif"
                                                        class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500" />
                                                    @error('username')
                                                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                                                    @enderror
                                                </div>

                                                <div>
                                                    <label
                                                        class="block text-sm font-semibold text-gray-900 mb-1">Password</label>
                                                    <input id="edit_password" type="password" name="password1"
                                                        placeholder="Password default: 123456"
                                                        class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500" />
                                                    @error('password')
                                                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                                                    @enderror
                                                </div>

                                                <div>
                                                    <label
                                                        class="block text-sm font-semibold text-gray-900 mb-1">Konfirmasi
                                                        Password</label>
                                                    <input type="password" name="password2"
                                                        placeholder="Password default: 123456"
                                                        class="block w-full px-3 py-2 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500" />
                                                    @error('password')
                                                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                                                    @enderror
                                                </div>

                                            </div>

                                            <div class="mt-6">
                                                <label
                                                    class="block text-sm font-semibold text-gray-900 mb-1">Alamat</label>
                                                <textarea id="edit_alamat" name="alamat2" placeholder="Masukkan alamat lengkap"
                                                    class="block w-full px-3 py-3 border border-gray-400 border-opacity-40 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500"
                                                    rows="4">{{ old('alamat') }}</textarea>
                                                @error('alamat')
                                                    <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                                                @enderror
                                            </div>

                                            <div class="flex justify-end mt-6">
                                                <div x-data="{ showModal: false, adminPassword: '' }">
                                                    <!-- Tombol Update -->
                                                    <button type="button" @click="showModal = true"
                                                        class="bg-blue-500 text-white px-5 py-2 rounded-md mr-3 flex items-center hover:bg-blue-600 transition duration-200">
                                                        <i class="fas fa-save mr-2"></i> Update
                                                    </button>

                                                    <!-- Modal Konfirmasi Password Admin -->
                                                    <div x-show="showModal"
                                                        class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50"
                                                        x-transition>
                                                        <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
                                                            <h2 class="text-xl font-semibold mb-4">Konfirmasi Aksi</h2>
                                                            <p class="mb-3">Masukkan password admin untuk melanjutkan:
                                                            </p>
                                                            <input type="password" x-model="adminPassword"
                                                                name="admin_password" placeholder="Password admin"
                                                                class="w-full border border-gray-300 p-2 rounded mb-4">

                                                            <div class="flex justify-end">
                                                                <!-- Tombol batal: hanya tutup modal -->
                                                                <button type="button" @click="showModal = false"
                                                                    class="px-4 py-2 bg-gray-300 text-gray-700 rounded mr-2 hover:bg-gray-400">
                                                                    Batal
                                                                </button>

                                                                <!-- Tombol lanjut -->
                                                                <button type="button"
                                                                    @click="if (adminPassword.length > 0) $refs.submitButton.click()"
                                                                    class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">
                                                                    Lanjutkan
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <!-- Tombol submit form tersembunyi -->
                                                    <button type="submit" x-ref="submitButton" class="hidden"></button>
                                                </div>

                                                <!-- Tombol batal luar (misalnya cancel edit form) -->
                                                <a href="javascript:void(0);"
                                                    class="bg-red-500 text-white px-5 py-2 rounded-md flex items-center hover:bg-red-600 transition duration-200">
                                                    <i class="fas fa-times mr-2"></i> Batal
                                                </a>
                                            </div>

                                        </form>
                                    </div>
                                </div>

                            </tr>
                        @endforeach
                    </tbody>
                </table>

                <div class="flex justify-between items-center mt-4">
                    <div class="text-sm">
                        Showing 1 to {{ $users->count() }} of {{ $users->total() ?? $users->count() }} entries
                    </div>
                    <div class="flex space-x-2">
                        {{-- Implement pagination links if using pagination --}}
                        {{ $users->links() ?? '' }}
                    </div>
                </div>

                <div class="mt-4 text-sm text-gray-600">
                    <p>
                        Mohon berhati-hati jika ingin menghapus data user, pastikan tidak sedang digunakan untuk login atau
                        proses lainnya!
                    </p>
                </div>
            </div>
        </div>
    </main>
@endsection

<script>
    document.addEventListener('DOMContentLoaded', () => {
        // Toggle baris aksi
        document.querySelectorAll('.toggle-action').forEach(button => {
            button.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                const row = document.getElementById(`action-row-${id}`);
                if (row) row.classList.toggle('hidden');
            });
        });
    });

    function openEditModal(id) {
        // Tampilkan modal
        document.getElementById('editModal').classList.remove('hidden');

        // Set form action
        document.getElementById('editUserForm').action = `/admin/edit-user/${id}`;

        // Ambil data dari server
        fetch(`/admin/get-user/${id}`)
            .then(response => response.json())
            .then(user => {
                // Isi form dengan data user
                document.getElementById('edit_nama_lengkap').value = user.nama_lengkap || '';
                document.getElementById('edit_email').value = user.username || '';
                document.getElementById('edit_no_hp').value = user.no_hp || '';
                document.querySelector('select[name="jenis_kelamin2"]').value = user.jenis_kelamin || '';
                document.querySelector('textarea[name="alamat2"]').value = user.alamat || '';

                // ✅ Tambahkan jika kamu juga ingin menampilkan id_users di form (readonly atau hidden)
                document.getElementById('edit_id_users').value = user.id_users || '';
            })
            .catch(error => {
                console.error('Gagal mengambil data user:', error);
            });
    }


    function closeEditModal() {
        document.getElementById('editModal').classList.add('hidden');
    }

</script>
