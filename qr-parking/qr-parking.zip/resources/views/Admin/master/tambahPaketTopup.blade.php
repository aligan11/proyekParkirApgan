@extends('app')

@section('content')
 <div class="max-w-7xl mx-auto mt-6 px-4">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

            {{-- Form Tambah Paket Topup (Kiri) --}}
            <div class="bg-white p-6 rounded shadow">
                <h2 class="text-2xl font-semibold border-b-4 border-red-600 pb-3 mb-6 flex items-center space-x-3">
                    <i class="fas fa-plus-circle text-red-600"></i>
                    <span>Tambah Paket Topup</span>
                </h2>
                <form action="{{ route('topup-parkir.store') }}" method="POST" class="space-y-5">
                    @csrf

                    <div>
                        <label for="nama" class="block mb-2 font-medium text-gray-700">Nama Paket</label>
                        <input type="text" id="nama" name="nama" placeholder="Contoh: Paket Silver, Paket Gold"
                            class="w-full border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-600"
                            required>
                    </div>

                    <div>
                        <label for="nominal" class="block mb-2 font-medium text-gray-700">Nominal Topup (Rp)</label>
                        <input type="number" step="0.01" id="nominal" name="nominal"
                            placeholder="Contoh: 50000, 100000"
                            class="w-full border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-600"
                            required>
                    </div>

                    <div>
                        <label for="biaya_admin" class="block mb-2 font-medium text-gray-700">Biaya Admin (Rp)</label>
                        <input type="number" step="0.01" id="biaya_admin" name="biaya_admin"
                            placeholder="Contoh: 1000, 2000" value="0"
                            class="w-full border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-600">
                    </div>

                    <div>
                        <label for="deskripsi" class="block mb-2 font-medium text-gray-700">Deskripsi (opsional)</label>
                        <textarea id="deskripsi" name="deskripsi" rows="3"
                            class="w-full border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-600"
                            placeholder="Keterangan tambahan..."></textarea>
                    </div>

                    <div class="flex items-center space-x-3">
                        <input type="checkbox" id="is_aktif" name="is_aktif" checked>
                        <label for="is_aktif" class="font-medium text-gray-700">Aktif</label>
                    </div>

                    <div class="flex space-x-4 mt-6">
                        <button type="submit"
                            class="bg-red-600 hover:bg-red-700 text-white font-semibold px-6 py-2 rounded flex items-center space-x-2">
                            <i class="fas fa-save"></i>
                            <span>Simpan</span>
                        </button>
                        <button type="reset"
                            class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-semibold px-6 py-2 rounded flex items-center space-x-2">
                            <i class="fas fa-times"></i>
                            <span>Batal</span>
                        </button>
                    </div>
                </form>
            </div>

            {{-- Tabel Data Paket Topup (Kanan) --}}
            <div class="bg-white p-6 rounded shadow overflow-auto">
                <h2 class="text-2xl font-semibold border-b-4 border-red-600 pb-3 mb-6 flex items-center space-x-3">
                    <i class="fas fa-table text-red-600"></i>
                    <span>Data Paket Topup</span>
                </h2>

                <table class="min-w-full table-auto border-collapse border border-gray-300  overflow-hidden shadow-sm">
                    <thead>
                        <tr class="bg-red-600 text-white">
                            <th class="border border-gray-300 px-3 py-2 text-left">No</th>
                            <th class="border border-gray-300 px-4 py-2 text-left">Nama Paket</th>
                            <th class="border border-gray-300 px-4 py-2 text-left">Nominal (Rp)</th>
                            <th class="border border-gray-300 px-4 py-2 text-center">Status</th>
                            <th class="border border-gray-300 px-4 py-2 text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($paketTopups as $index => $paket)
                            <tr class="{{ $index % 2 == 0 ? 'bg-gray-50' : 'bg-white' }}">
                                <td class="border border-gray-300 px-4 py-2">{{ $paketTopups->firstItem() + $index }}</td>
                                <td class="border border-gray-300 px-4 py-2">{{ $paket->nama }}</td>
                                <td class="border border-gray-300 px-4 py-2">Rp
                                    {{ number_format($paket->nominal, 2, ',', '.') }}</td>
                               
                                <td class="border border-gray-300 px-4 py-2 text-center">
                                    @if ($paket->is_aktif)
                                        <span
                                            class="px-2 py-1 text-sm font-semibold text-green-600 bg-green-100 rounded-full">Aktif</span>
                                    @else
                                        <span
                                            class="px-2 py-1 text-sm font-semibold text-red-600 bg-red-100 rounded-full">Nonaktif</span>
                                    @endif
                                </td>
                                <td class="border border-gray-300 px-4 py-2 text-center">
                                    <div class="flex justify-center gap-2">
                                        {{-- Tombol Edit --}}
                                        <a href="#" data-modal-target="modalEdit{{ $paket->id }}"
                                            data-modal-toggle="modalEdit{{ $paket->id }}"
                                            class="inline-flex items-center px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition duration-150"
                                            title="Edit Paket">
                                            <i class="fas fa-edit mr-1"></i> Edit
                                        </a>
                                        <!-- Modal Edit -->
                                        <div id="modalEdit{{ $paket->id }}" tabindex="-1"
                                            class="hidden fixed top-0 left-0 right-0 z-50 flex items-center justify-center w-full h-full bg-black bg-opacity-50">
                                            <div class="bg-white rounded-lg shadow-lg w-full max-w-md p-6">
                                                <div class="flex justify-between items-center mb-4">
                                                    <h3 class="text-xl font-semibold text-gray-800">Edit Paket Topup</h3>
                                                    <button type="button" class="text-gray-500 hover:text-gray-700"
                                                        data-modal-hide="modalEdit{{ $paket->id }}">
                                                        <i class="fas fa-times"></i>
                                                    </button>
                                                </div>
                                                <form action="{{ route('topup-parkir.update', $paket->id) }}"
                                                    method="POST" class="space-y-4">
                                                    @csrf
                                                    @method('PUT')

                                                    <div>
                                                        <label class="block text-sm font-medium text-gray-700">Nama
                                                            Paket</label>
                                                        <input type="text" name="nama" value="{{ $paket->nama }}"
                                                            class="w-full border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-600"
                                                            required>
                                                    </div>

                                                    <div>
                                                        <label class="block text-sm font-medium text-gray-700">Nominal Topup
                                                            (Rp)
                                                        </label>
                                                        <input type="number" name="nominal" step="0.01"
                                                            value="{{ $paket->nominal }}"
                                                            class="w-full border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-600"
                                                            required>
                                                    </div>

                                                    <div>
                                                        <label class="block text-sm font-medium text-gray-700">Biaya Admin
                                                            (Rp)</label>
                                                        <input type="number" name="biaya_admin" step="0.01"
                                                            value="{{ $paket->biaya_admin }}"
                                                            class="w-full border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-600">
                                                    </div>

                                                    <div>
                                                        <label
                                                            class="block text-sm font-medium text-gray-700">Deskripsi</label>
                                                        <textarea name="deskripsi" rows="3"
                                                            class="w-full border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-600">{{ $paket->deskripsi }}</textarea>
                                                    </div>

                                                    <div class="flex items-center space-x-2">
                                                        <input type="checkbox" name="is_aktif"
                                                            id="editAktif{{ $paket->id }}"
                                                            {{ $paket->is_aktif ? 'checked' : '' }}>
                                                        <label for="editAktif{{ $paket->id }}"
                                                            class="text-sm text-gray-700 font-medium">Aktif</label>
                                                    </div>

                                                    <div class="flex justify-end gap-3 pt-4">
                                                        <button type="button"
                                                            class="bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded"
                                                            data-modal-hide="modalEdit{{ $paket->id }}">Batal</button>
                                                        <button type="submit"
                                                            class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded font-semibold flex items-center gap-2">
                                                            <i class="fas fa-save"></i> Simpan
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>



                                        {{-- Tombol Hapus --}}
                                        <form id="delete-form-{{ $paket->id }}"
                                            action="{{ route('topup-parkir.destroy', $paket->id) }}" method="POST"
                                            class="inline">
                                            @csrf
                                            @method('DELETE')
                                            <button type="button"
                                                class="inline-flex items-center px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white text-sm font-medium rounded-lg transition duration-150"
                                                onclick="confirmDelete({{ $paket->id }})" title="Hapus Paket">
                                                <i class="fas fa-trash-alt mr-1"></i> Hapus
                                            </button>
                                        </form>

                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="8" class="border border-gray-300 px-4 py-2 text-center text-gray-500">
                                    Data paket topup belum tersedia.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>


                <div class="mt-4">
                    {{ $paketTopups->links() }}
                </div>
            </div>

        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
    function confirmDelete(id) {
        Swal.fire({
            title: 'Apakah kamu yakin?',
            text: "Data ini akan dihapus secara permanen!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#e3342f',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Ya, hapus!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById(`delete-form-${id}`).submit();
            }
        });
    }
</script>


    @if (session('success'))
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil',
                text: '{{ session('success') }}',
                confirmButtonColor: '#3085d6',
                confirmButtonText: 'OK'
            });
        </script>
    @endif

    <script>
        document.querySelectorAll('[data-modal-toggle]').forEach(btn => {
            btn.addEventListener('click', () => {
                const targetId = btn.getAttribute('data-modal-target');
                document.getElementById(targetId).classList.remove('hidden');
            });
        });

        document.querySelectorAll('[data-modal-hide]').forEach(btn => {
            btn.addEventListener('click', () => {
                const targetId = btn.getAttribute('data-modal-hide');
                document.getElementById(targetId).classList.add('hidden');
            });
        });
    </script>
@endsection
