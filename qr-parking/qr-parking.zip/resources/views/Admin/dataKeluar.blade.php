@extends('app')
@section('content')

   <div class="max-w-7xl mx-auto mt-4 px-4">
        <div class="bg-white p-6 rounded shadow-md">
            <h2 class="text-xl font-bold mb-4">APLIKASI PARKIR KENDARAAN <span class="text-red-500">{{ $logo->nama_aplikasi }}</span></h2>
            <div class="grid grid-cols-2 gap-4">
                <div class="flex flex-col">
                    <div class="border border-red-500 p-4 rounded flex-grow relative">
                        <h3 class="text-lg font-bold mb-4"><i class="fas fa-plus-circle"></i> Form Tambah Data Parkir Keluar dengan QR Code</h3>

                        <!-- TAMPILAN BARCODE -->
                        <div id="barcodeSection" class="text-center">
                            <img src="{{ asset('img/qr.png') }}" alt="QR Code" class="w-80 h-80 m-auto">
                            <p class="mt-4 font-bold text-gray-800">Scan Disini dengan <span id="kodeBarcodeText">Mobile Apps</span></p>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="border border-gray-300 p-4 rounded h-full">
                        <h3 class="text-lg font-bold mb-4"><i class="fas fa-table"></i> Data Tabel Parkir Keluar Hari Ini</h3>
                        <div class="flex justify-between items-center mb-4">
                            <div>
                                <label>Show</label>
                                <select class="border rounded p-1">
                                    <option>10</option>
                                </select>
                                <label>entries</label>
                            </div>
                            <div>
                                <label>Search:</label>
                                <input type="text" class="border rounded p-1">
                            </div>
                        </div>
                        <table class="w-full border-collapse">
                            <thead>
                                <tr class="bg-red-500 text-white">
                                    <th class="border p-2">No.</th>
                                    <th class="border p-2">Kode Parkir</th>
                                    <th class="border p-2">Plat Nomor</th>
                                    <th class="border p-2">Jenis Kendaraan</th>
                                    <th class="border p-2">Waktu Keluar</th>
                                </tr>
                            </thead>
                           <tbody>
                                @foreach ($jenisKendaraan as  $item)
                                    <tr class="bg-gray-100">
                                        <td class="border p-2 text-center">{{ $loop->iteration + $jenisKendaraan->firstItem()-1}}</td>
                                        <td class="border p-2">{{ $item->kode_parkir }}</td>
                                        <td class="border p-2">{{ $item->platNomor->plat_nomor }}</td>
                                        <td class="border p-2">{{ $item->tipeKendaraan->jenis->nama_kendaraan }}</td>
                                        <td class="border p-2">
                                            <div class="bg-gray-200 p-1 rounded text-center">
                                                <div>{{ $item->waktu_keluar }}</div>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        <div class="flex justify-between items-center mt-4">
                            <div>Showing 1 to 4 of 4 entries</div>
                            <div class="flex space-x-2">
                                <button class="bg-gray-300 px-2 py-1 rounded">Previous</button>
                                <button class="bg-blue-500 text-white px-2 py-1 rounded">1</button>
                                <button class="bg-gray-300 px-2 py-1 rounded">Next</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
