@extends('app')
@section('content')
<div class="max-w-7xl mx-auto mt-6 px-4">
    <div class="bg-white shadow-md rounded-lg p-6">
        <div class="border-b-2 border-red-500 pb-2 mb-4">
            <h2 class="text-lg font-bold text-center">Form Rincian/Ubah Data Aplikasi</h2>
        </div>

        <div class="flex justify-center mb-4">
            <img alt="Logo Parkir" class="w-24 h-24 rounded-full border object-cover"
                src="{{ asset('img/' . ($property->logo_aplikasi ?? 'parking.jpg')) }}" />
        </div>

        @if (session('success'))
            <div class="bg-green-100 text-green-800 p-2 rounded mb-4 text-sm">
                {{ session('success') }}
            </div>
        @endif

        <form id="resetForm" action="{{ route('aplikasi.update') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-gray-700 font-semibold mb-1">Nama Aplikasi</label>
                    <input type="text" name="nama_aplikasi" value="{{ old('nama_aplikasi', $property->nama_aplikasi) }}"
                        class="w-full border rounded px-3 py-2 text-sm" required>
                </div>

                <div>
                    <label class="block text-gray-700 font-semibold mb-1">Kode Parkir</label>
                    <input type="text" name="kode_parkir" value="{{ old('kode_parkir', $property->kode_parkir) }}"
                        class="w-full border rounded px-3 py-2 text-sm" required>
                </div>

                <div>
                    <label class="block text-gray-700 font-semibold mb-1">Ganti Logo Aplikasi</label>
                    <input type="file" name="logo" class="w-full border rounded px-3 py-2 text-sm">
                </div>

                <div>
                    <label class="block text-gray-700 font-semibold mb-1">Perusahaan/Pengelola Parkir</label>
                    <input type="text" name="nama_perusahaan" value="{{ old('nama_perusahaan', $property->owner_parkir) }}"
                        class="w-full border rounded px-3 py-2 text-sm">
                </div>

                <div>
                    <label class="block text-gray-700 font-semibold mb-1">Alamat Perusahaan</label>
                    <input type="text" name="alamat" value="{{ old('alamat', $property->alamat_perusahaan) }}"
                        class="w-full border rounded px-3 py-2 text-sm">
                </div>

                <div>
                    <label class="block text-gray-700 font-semibold mb-1">Email</label>
                    <input type="email" name="email" value="{{ old('email', $property->email_perusahaan) }}"
                        class="w-full border rounded px-3 py-2 text-sm">
                </div>

                <div>
                    <label class="block text-gray-700 font-semibold mb-1">Nomor HP</label>
                    <input type="text" name="telepon" value="{{ old('telepon', $property->no_perusahaan) }}"
                        class="w-full border rounded px-3 py-2 text-sm">
                </div>
            </div>

            <div class="flex justify-end gap-2 mt-6">
                <button type="button" onclick="confirmReset()"
                    class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded flex items-center space-x-2 shadow text-sm">
                    <i class="fas fa-undo"></i>
                    <span>Reset</span>
                </button>

                <a href="{{ url()->previous() }}"
                    class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded flex items-center space-x-2 shadow text-sm">
                    <i class="fas fa-times"></i>
                    <span>Batal</span>
                </a>

                <button type="submit"
                    class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded flex items-center space-x-2 shadow text-sm">
                    <i class="fas fa-save"></i>
                    <span>Simpan</span>
                </button>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    @if (session('success'))
        Swal.fire({
            icon: 'success',
            title: 'Berhasil!',
            text: '{{ session('success') }}',
            confirmButtonColor: '#3085d6',
            confirmButtonText: 'OK'
        });
    @endif

    function confirmReset() {
        Swal.fire({
            title: 'Yakin reset ke default?',
            text: "Data akan kembali ke pengaturan awal.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, reset!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('resetForm').submit();
            }
        });
    }
</script>
@endsection
